package org.cg.bdd.exception;

public class InvalidCredentials extends Exception {

	private String errmsg;

	public InvalidCredentials(String errmsg) {
		super();
		this.errmsg = errmsg;
	}
	
}
