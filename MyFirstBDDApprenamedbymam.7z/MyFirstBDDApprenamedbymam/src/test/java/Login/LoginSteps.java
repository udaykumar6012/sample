package Login;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.HotelLoginPageFactory;


public class LoginSteps {


	WebDriver driver;
	private HotelLoginPageFactory objhlpg;

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		//driver = new FirefoxDriver();

		System.setProperty("webdriver.chrome.driver", "C:/StudyMaterial/BDD/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objhlpg = new HotelLoginPageFactory(driver);

		driver.get("file:///C:/StudyMaterial/BDD/hotelBooking/login.html");
	}

	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page() throws Throwable {
		String actualTitle = driver.findElement(By.xpath("//*[@id='mainCnt']/div[1]/div[1]/h1")).getText();
		// assertEquals("TestFailed", "Hotel Booking", actualTitle);

		String expectedTitle="Hotel Booking Application";
		if(expectedTitle.equals(actualTitle))
			System.out.println("Page Heading Matched...");
		else
			System.out.println("Page Heading does not matched...");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//driver.close();

	}

		@When("^user enters valid username, valid password$")
	public void user_enters_valid_username_valid_password() throws Throwable {
	    objhlpg.setPfuname("capgemini");
	    objhlpg.setPfpwd("capg1234");
	    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	    objhlpg.setPflogin();
	  // driver.close();
	}

	@Then("^navigate to hotelBooking$")
	public void navigate_to_hotelBooking() throws Throwable {
	   driver.navigate().to("file:///C:/StudyMaterial/BDD/hotelBooking/hotelbooking.html");
	   driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	   //driver.close();
	}
/*
	@When("^user doesnot enter either username or password$")
	public void user_doesnot_enter_either_username_or_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^clicks the Login Button$")
	public void clicks_the_Login_Button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display appropriate messaage$")
	public void display_appropriate_messaage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	 */
}
