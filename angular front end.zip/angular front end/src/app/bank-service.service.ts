import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BankAccount } from './BankAccount';


@Injectable({
  providedIn: 'root'
})
export class BankServiceService {
  userName:string;
  loggedInStatus:boolean=false;
  accountId:number;

private getDetailsByUsernameURL:string;
 constructor(private http:HttpClient) { }

 addCustomer(bank:BankAccount):Observable<boolean>
 {
 return this.http.post<boolean>("http://localhost:9091/customer",bank);
 }

 depositMoney(accountId:number,balance:number):Observable<number>
 {
 let url:string = "http://localhost:9091/customer/deposit/"+accountId+"/"+balance;
 console.log(url);
 return this.http.put<number>(url,"");
 }

 withdrawMoney(accountId:number,balance:number):Observable<number>
 {
 let url:string = "http://localhost:9091/customer/withdraw/"+accountId+"/"+balance;
 console.log(url);
 return this.http.put<number>(url,"");
 }

 loginByUser(userName:string,password:string):Observable<number>
 {
 let url:string = "http://localhost:9091/customer/login/"+userName+"/"+password;
 console.log(url);
 return this.http.get<number>(url);
 }

 fundTransferUpdate(accountId:number,recaccountNo:number,amount:number):Observable<number>
 {
 let url:string = "http://localhost:9091/customer/fundtransfer/"+accountId+"/"+recaccountNo+"/"+amount;
 console.log(url);
 return this.http.put<number>(url,"");
 }

 setAccountNo(accno){
  this.accountId=accno;
  }

  getAccountNo(){
    return this.accountId;
    }
    
    setUserName(userName:string){
    this.userName=userName;
    }
    
    getUserName(){
    return this.userName;
    }

    showBalance(accountId:string):Observable<number>{
      let url = "http://localhost:9091/customer/showbalance/"+accountId;
      return this.http.get<number>(url);
      }
      
    getTransactionsByAccountNo():Observable<string[]>{
      let url = "http://localhost:9091/getTransactions/all/"+this.accountId;
      console.log(url);
      return this.http.get<string[]>(url);
      }

    setLoggedInStatus(status:boolean){
      this.loggedInStatus=status;
          }
        
      getLoggedInStatus(){
        return this.loggedInStatus;
        }
      


}
