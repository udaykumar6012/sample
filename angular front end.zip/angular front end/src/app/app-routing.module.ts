import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositAmountComponent } from './deposit-amount/deposit-amount.component';
import { WithdrawAmountComponent } from './withdraw-amount/withdraw-amount.component';
import { TransferAmountComponent } from './transfer-amount/transfer-amount.component';
import { ShowTransactionsComponent } from './show-transactions/show-transactions.component';
import { LoginComponent } from './login/login.component';
import { MainloginComponent } from './mainlogin/mainlogin.component';



const routes: Routes = [
{path : 'signup', component:CreateAccountComponent},
{path : 'login',component:MainloginComponent},
{path: 'log',component:LoginComponent},
{path : 'create',component:CreateAccountComponent},
{path : 'show',component:ShowBalanceComponent},
{path : 'deposit',component:DepositAmountComponent},
{path : 'withdraw',component:WithdrawAmountComponent},
{path : 'transfer',component:TransferAmountComponent},
{path : 'transactions',component:ShowTransactionsComponent},
{path:'',redirectTo:'',pathMatch:'full'}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 
  
}
