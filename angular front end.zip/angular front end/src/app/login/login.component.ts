import { Component, OnInit } from '@angular/core';
import { BankAccount } from '../BankAccount';
import { Router } from '@angular/router';
import { BankServiceService } from '../bank-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  errorMessage:string;
  accountId:number;
  bank:BankAccount=new BankAccount();
  constructor( public router: Router,private service: BankServiceService) { }

  ngOnInit() {
  }
  login(userName,password) {
    console.log(this.bank);
    this.service.loginByUser(userName,password).subscribe(data =>{
    this.accountId=data;
    this.service.setUserName(userName);
    this.service.setAccountNo(this.accountId);
    this.service.setLoggedInStatus(true);
    alert("User Details Validated, Redirecting");
    this.router.navigate(['/login']);
    
    }, error => alert("Details Invalid, Try again"));

  
  }
}
