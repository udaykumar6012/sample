package com.cg.exception;
/*Created By:CH.Saranya
Created On:23/07/2019
purpose:Exception Class for Handling Exceptions

*/

public class SessionException extends Exception {

	public SessionException() {
		// TODO Auto-generated constructor stub
		super();
	}
	public SessionException(String message) {
		super(message);
	}

}
