package com.cg.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.bean.ScheduleSession;
import com.cg.exception.SessionException;
import com.cg.service.IScheduledService;
/*Created By:CH.Saranya
Created On:23/07/2019
purpose:Controller class which is used to implement all the methods and to create url's

*/

@RestController
public class ScheduleSessionController {
	@Autowired
	private IScheduledService service;
	
	@RequestMapping(value = "/createsession", method = RequestMethod.POST)
	public List<ScheduleSession> createSession(@RequestBody ScheduleSession scheduleSession) throws SessionException {
		return  service.createSession(scheduleSession);
	}

	@RequestMapping(value = "/getAllSessions", method = RequestMethod.GET)
	public List<ScheduleSession> getAllSessions() {
		return  service.getAllSessions();
	}
	
	@RequestMapping(value = "/updateSession/{sid}/{duration}/{facultyName}", method = RequestMethod.POST)
	public ScheduleSession updateSession(@PathVariable("sid") Integer sessionId,@PathVariable("duration") Integer duration,
			@PathVariable("facultyName") String facultyName) {
		return  service.updateSession(sessionId, duration,facultyName);
	}
	@RequestMapping(value = "/deleteSession/{sid}", method = RequestMethod.DELETE)
	public String deleteSession(@PathVariable("sid") Integer sessionId) {
		service.deleteSession(sessionId);
		return  sessionId+" is deleted";
	}
	

	public ScheduleSessionController() {
		// TODO Auto-generated constructor stub
	}

}
