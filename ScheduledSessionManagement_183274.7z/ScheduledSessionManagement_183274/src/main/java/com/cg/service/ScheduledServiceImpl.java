package com.cg.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.ScheduleSession;

import com.cg.dao.ScheduledSessionRepository;
import com.cg.exception.SessionException;
/*Created By:CH.Saranya
Created On:23/07/2019
purpose:Service Implementation for implementing methods

*/






@Service
public class ScheduledServiceImpl implements IScheduledService {
	@Autowired
	private ScheduledSessionRepository repository;

	

	@Override
	public List<ScheduleSession> createSession(ScheduleSession scheduleSession) throws SessionException {
		// TODO Auto-generated method stub
		try {
			try {
			repository.save(scheduleSession);
			}catch(Exception e) {
				throw new SessionException(ExceptionMessage.Message1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return repository.findAll();
	}

	@Override
	public ScheduleSession updateSession(Integer sessionId, Integer duration, String facultyName) {
		// TODO Auto-generated method stub
	ScheduleSession scheduleSession=repository.findById(sessionId).get();
	scheduleSession.setDuration(duration);
	scheduleSession.setFacultyName(facultyName);
	return repository.save(scheduleSession);
	}

	@Override
	public void deleteSession(Integer sessionId) {
		// TODO Auto-generated method stub
	
		repository.deleteById(sessionId);
		
	}

	@Override
	public List<ScheduleSession> getAllSessions() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}
	public ScheduledServiceImpl() {
		// TODO Auto-generated constructor stub
	}

}
