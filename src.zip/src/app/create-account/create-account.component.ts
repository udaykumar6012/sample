import { Component, OnInit } from '@angular/core';
import { BankAccount } from '../BankAccount';
import { BankServiceService } from '../bank-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {

  bank:BankAccount=new BankAccount();
  constructor(public router: Router,private service: BankServiceService) { }

  ngOnInit() {
  }

  save(){
    console.log(this.bank);
    this.service.addCustomer(this.bank).subscribe(data => console.log(data));
    alert("User Details Validated, Redirecting");
    this.router.navigate(['/login']);
  }
}
