import { Component, OnInit } from '@angular/core';
import { BankAccount } from '../BankAccount';
import { BankServiceService } from '../bank-service.service';

@Component({
  selector: 'app-deposit-amount',
  templateUrl: './deposit-amount.component.html',
  styleUrls: ['./deposit-amount.component.css']
})
export class DepositAmountComponent implements OnInit {
 
  accountId:number;
  balance:number;
  
  bank:BankAccount=new BankAccount();
  constructor(private service: BankServiceService) { }

  ngOnInit() {
  }
  depositMoney(accountId:number,balance:number){
    this.service.depositMoney(accountId,balance).subscribe(data =>{
    this.accountId=data;
    this.balance=data;
    })
    
   }

}
