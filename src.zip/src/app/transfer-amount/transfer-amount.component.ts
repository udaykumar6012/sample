import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../bank-service.service';

@Component({
  selector: 'app-transfer-amount',
  templateUrl: './transfer-amount.component.html',
  styleUrls: ['./transfer-amount.component.css']
})
export class TransferAmountComponent implements OnInit {

  constructor( private service: BankServiceService) { }
  balance:number


  ngOnInit() {
  }
  fundTransferUpdate(accountNo,recaccountNo,amount)
  { 
 this.service.fundTransferUpdate(accountNo,recaccountNo,amount).subscribe(data => {
 this.balance = data;
  });

}}
