import { Component, OnInit } from '@angular/core';
import { BankAccount } from '../BankAccount';
import { BankServiceService } from '../bank-service.service';

@Component({
  selector: 'app-withdraw-amount',
  templateUrl: './withdraw-amount.component.html',
  styleUrls: ['./withdraw-amount.component.css']
})
export class WithdrawAmountComponent implements OnInit {

  accountId:number;
  balance:number;
  
  bank:BankAccount=new BankAccount();
  constructor(private service: BankServiceService) { }

  ngOnInit() {
  }

  withdrawMoney(accountId:number,balance:number){
    this.service.withdrawMoney(accountId,balance).subscribe(data =>{
    this.accountId=data;
    this.balance=data;
    })
    
   }

}
