import { Component, OnInit } from '@angular/core';
import { BankAccount } from '../BankAccount';
import { Router } from '@angular/router';
import { BankServiceService } from '../bank-service.service';

@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {

  balance:number;
  bank:BankAccount=new BankAccount();
  constructor( public router: Router,private service: BankServiceService) { }

  ngOnInit() {
  }
  showBalance(accountId){
    this.service.showBalance(accountId).subscribe(data =>{
    this.balance=data;
    })
  }

}
