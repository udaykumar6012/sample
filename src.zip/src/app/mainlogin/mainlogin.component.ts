import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainlogin',
  templateUrl: './mainlogin.component.html',
  styleUrls: ['./mainlogin.component.css']
})
export class MainloginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
