export class BankAccount{

  
       
        fullName:string;
        userName:string;
        email:string;
        password:string;
        phoneNumber:number;
        balance:number
    
    
    
}