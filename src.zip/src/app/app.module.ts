import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositAmountComponent } from './deposit-amount/deposit-amount.component';
import { WithdrawAmountComponent } from './withdraw-amount/withdraw-amount.component';
import { TransferAmountComponent } from './transfer-amount/transfer-amount.component';
import { ShowTransactionsComponent } from './show-transactions/show-transactions.component';
import { LoginComponent } from './login/login.component';
import { MainloginComponent } from './mainlogin/mainlogin.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { HttpClientModule } from '@angular/common/http';



@NgModule({
  declarations: [
    AppComponent,
    CreateAccountComponent,
    ShowBalanceComponent,
    DepositAmountComponent,
    WithdrawAmountComponent,
    TransferAmountComponent,
    ShowTransactionsComponent,
    LoginComponent,
    MainloginComponent,
    WelcomeComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule 
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
