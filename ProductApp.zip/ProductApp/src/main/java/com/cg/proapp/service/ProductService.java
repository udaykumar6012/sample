package com.cg.proapp.service;
import java.util.List;
import com.cg.proapp.bean.Product;
public interface ProductService {
public List<Product> addProduct(Product pro);
public Product getProductById(int id);
public List<Product> getProductByCategory(String category);
public List<Product> getAllProducts();
public void deleteProduct(int id);
public List<Product> updateProduct(int id,Product pro);
public List<Product> getProductByPrice(int price1, int price2);
}
