package com.cg.proapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.proapp.bean.Product;
import com.cg.proapp.dao.ProductDao;
@Service
public class ProductServieImpl implements ProductService{

	@Autowired
	ProductDao productdao;
	@Override
	public List<Product> addProduct(Product pro) {
		productdao.save(pro);
		return productdao.findAll();
	}

	@Override
	public Product getProductById(int id) {
		return productdao.findById(id).get();
	}

	@Override
	public List<Product> getProductByCategory(String category) {
 
		return productdao.getProductByCategory(category);
	}

	@Override
	public List<Product> getAllProducts() {
		
		return productdao.findAll();
	}

	@Override
	public void deleteProduct(int id) {
       productdao.deleteById(id);		
	}
	@Override
	public List<Product> updateProduct(int id, Product pro) {
		Optional<Product> optional=productdao.findById(id);
		if(optional.isPresent())
        {
            Product product=optional.get();
          product.setPrice(pro.getPrice());
            product.setQuantity(pro.getQuantity());
            productdao.save(product);
            return getAllProducts();
        }
		return null;
	}
	@Override
	public List<Product> getProductByPrice(int price1, int price2) {
		// TODO Auto-generated method stub
		return productdao.getProductByPrice(price1, price2);
	}

}
