package com.cg.proapp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.cg.proapp.bean.Product;




public interface ProductDao extends JpaRepository<Product, Integer>{
	@Query("from Product where category=:c")
	   List<Product> getProductByCategory(@Param("c") String category);
	
    @Query("from Product where price between :price1 and :price2")
     List<Product> getProductByPrice(@Param("price1") int price1, @Param("price2") int price2);

}
