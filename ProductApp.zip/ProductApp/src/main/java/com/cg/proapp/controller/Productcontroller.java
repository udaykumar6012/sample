package com.cg.proapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.proapp.bean.Product;
import com.cg.proapp.service.ProductService;

@RestController
public class Productcontroller {

	@Autowired
	ProductService productservice;
	
	@RequestMapping("/products")
    public List<Product> getAllProduct(){
        return productservice.getAllProducts();  
    }
	
	
	 @RequestMapping("/products/{id}")
	    public Product getProduct(@PathVariable int id){
	        return productservice.getProductById(id);
	        
	    }
	    
	    @RequestMapping(value="/products/{id}",method=RequestMethod.DELETE)
	    
	    public ResponseEntity<String> deleteProduct(@PathVariable int id){
	        productservice.deleteProduct(id);
	        return new ResponseEntity<String>("Product with the id "+id+" deleted",HttpStatus.OK);
	        
	    }
	    
	    @RequestMapping(value="/products",method=RequestMethod.POST)
	
	    public ResponseEntity<String> addproduct(@RequestBody Product prod) {
	    	productservice.addProduct(prod);
	        return new ResponseEntity<String>("Product Successfully added", HttpStatus.OK);
	        }
	        
	    
	    
	    
	    @RequestMapping(value="/products/{id}",method=RequestMethod.PUT)
	  
//	    public ResponseEntity<String> updateProduct(@RequestBody Product pro) {
//	        
//	        productservice.updateProduct( 0, pro);
//	        return new ResponseEntity<String>("Product Successfully updated",HttpStatus.OK);
//	        
	        
	        
	  
	        public List<Product> updateProduct(@PathVariable int id, @RequestBody Product pro) {
	        return productservice.updateProduct(id, pro);
	        }
	        
	     
	    
	    @RequestMapping("/products/category")
	    public List<Product> getProductByCategory(@RequestParam("category") String cate){
	        return productservice.getProductByCategory(cate);
	        
	    }
	    
	    @RequestMapping("/products/price")
	    public List<Product> getProductByPrice(@RequestParam int price1, int price2){
	        return productservice.getProductByPrice(price1, price2);
	    }
	    

	 


	
}
