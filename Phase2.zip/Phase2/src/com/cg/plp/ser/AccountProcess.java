package com.cg.plp.ser;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.plp.bean.AccountDetails;
import com.cg.plp.bean.TransactionDetails;
import com.cg.plp.dao.AccountStore;



public class AccountProcess implements AccountOperations {
AccountStore store= new AccountStore();
	@Override
	public void createAccount(AccountDetails account) {
		// TODO Auto-generated method stub
		try {
			store.accountCreation(account);
		} catch (SQLException exception) {
			// TODO Auto-generated catch block
			exception.printStackTrace();
		}
	}

	@Override
	public double showBalance(int accountNumber) throws SQLException  {
		// TODO Auto-generated method stub
		
			return store.displayBalance(accountNumber);
		
		
	}

	@Override
	public void deposit(int accountNumber, double credit) throws SQLException {
		// TODO Auto-generated method stub
		store.depositAmount(accountNumber, credit);
	}

	@Override
	public void withdraw(int accountNumber, double debit) throws SQLException {
		// TODO Auto-generated method stub
		 store.withdrawAmount(accountNumber, debit);;
	}

	

	@Override
	public ResultSet getTransactionDetails(int accountNumber) throws SQLException {
		// TODO Auto-generated method stub
		 
		return  store.showTransactions(accountNumber);
	}

	
	

}