package com.cg.plp.ser;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.cg.plp.bean.AccountDetails;
import com.cg.plp.bean.TransactionDetails;


public interface AccountOperations {

	public void createAccount(AccountDetails account);

	public double showBalance(int accountNumber) throws SQLException;

	public void deposit(int accountNumber, double credit) throws SQLException;

	public void withdraw(int accountNumber, double debit) throws SQLException;

	

	public ResultSet getTransactionDetails(int accountNumber) throws SQLException;

	

}
