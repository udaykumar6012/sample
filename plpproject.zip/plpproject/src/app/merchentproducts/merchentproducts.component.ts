import { Component, OnInit } from '@angular/core';
import { Iproducts } from '../iproducts';
import { ProductsService } from '../products.service';

@Component({
  selector: 'app-merchentproducts',
  templateUrl: './merchentproducts.component.html',
  styleUrls: ['./merchentproducts.component.css']
})
export class MerchentproductsComponent implements OnInit {
product:Iproducts[];
  constructor(public productService:ProductsService) { }

  ngOnInit() {
  }


  showAllProducts(merchantId){
    this.productService.showAllProducts(merchantId).subscribe(response=>this.handleSuccessfulResponse(response));
  }

  handleSuccessfulResponse(response){
    this.product=response;
    console.log(this.productService);
  }

}
