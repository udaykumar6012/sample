import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchentproductsComponent } from './merchentproducts.component';

describe('MerchentproductsComponent', () => {
  let component: MerchentproductsComponent;
  let fixture: ComponentFixture<MerchentproductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchentproductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchentproductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
