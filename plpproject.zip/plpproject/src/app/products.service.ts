import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import {HttpClient} from '@angular/common/http'
import { Iproducts } from './iproducts';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  product:Iproducts[]
  constructor(private http:HttpClient) { }
  showAllProducts(merchantId):Observable<Iproducts[]>
 {
 return this.http.get<Iproducts[]>("http://localhost:8081/api/prodcuts/"+merchantId);
 }
}
