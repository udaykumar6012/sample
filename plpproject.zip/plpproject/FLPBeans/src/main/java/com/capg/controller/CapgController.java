package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.CartItem;
import com.capg.bean.Customer;
import com.capg.bean.Merchant;
import com.capg.bean.Product;
import com.capg.bean.WishItem;
//import com.capg.service.CapgService;
import com.capg.service.CapgService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CapgController {

	@Autowired CapgService capgService;
	
	@PostMapping("/register")
	public void registerCustomer(@RequestBody Customer customer) {
		capgService.registerCustomer(customer);
	}
	@PostMapping("/addWish/{custId}")
	public void addCustomerWish(@PathVariable String custId,@RequestBody WishItem wish) {
		capgService.addCustomerWish(custId,wish);
	}
	@RequestMapping("/api/prodcuts/{merchantid}")
	public List<Product> getProducts(@PathVariable String merchantid){
		return capgService.getProductByMerchant(merchantid);
	}  
	@RequestMapping(value="/addproducts",method=RequestMethod.POST)
	public void addProducts(@RequestBody Product pro) {
		capgService.addProduct(pro);
	}
	@RequestMapping(value="/addmerchants",method=RequestMethod.POST)
	public void addMerchant(@RequestBody Merchant merchant) {
		capgService.addMerchant(merchant);
	}
	@RequestMapping("/products")
	public List<Product> getAllProducts() {
		return capgService.getAllProducts();
	}
	@RequestMapping("/merchants")
	public List<Merchant> getAllMerchants(){
		return capgService.getAllMerchants();
	}
	@RequestMapping("/customers")
	public List<Customer> getAllCustomers(){
		return capgService.getAllCustomers();
	}
	

    @PostMapping("/addtoCart/{custId}")
    public void addtoCart(@PathVariable String custId,@RequestBody CartItem cart) {
        capgService.addtoCart(custId, cart);
    }
   
    @DeleteMapping("/deleteProduct/{cartId}")
    public List<CartItem> deleteFromCart(@PathVariable String cartId){
        return capgService.deleteFromCart(cartId);       
    }
   
    @RequestMapping("/getCartList/{custId}")
    public List<CartItem> getCartProducts(String custId){
        return capgService.getCartProducts(custId);       
    }

}
