package com.capg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlpBeansApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlpBeansApplication.class, args);
	}

}
