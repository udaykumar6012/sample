package com.capg.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import com.capg.bean.CartItem;
import com.capg.bean.Customer;
import com.capg.bean.Merchant;
import com.capg.bean.Product;
import com.capg.bean.WishItem;
import com.capg.dao.CapgCartItemRepo;
import com.capg.dao.CapgCustomerRepo;
import com.capg.dao.CapgMerchantRepo;
import com.capg.dao.CapgProductRepo;
import com.capg.dao.CapgWishItemRepo;





@Service
public class CapgService {

	@Autowired CapgCustomerRepo customerRepo;
	@Autowired CapgMerchantRepo merchantDao;
	@Autowired CapgWishItemRepo customerWishRepo;
	@Autowired CapgProductRepo productRepo;
	@Autowired CapgCartItemRepo customerCartRepo;
	public void registerCustomer(Customer customer) {
		customerRepo.save(customer);
	}
	
	public Customer findCustomerById(String custId) {  
		return customerRepo.findById(custId).get();
	}
	
	public void addCustomerWish(String custId,WishItem wish) {
		Customer customer = findCustomerById(custId);
		List<WishItem> wishList = customer.getWishItems();
		wishList.add(wish);
		customer.setWishItems(wishList);
		customerWishRepo.save(wish);
		customerRepo.save(customer);
	}
	
	
	public void addProduct(Product pro) {
		// TODO Auto-generated method stub
		productRepo.save(pro);
	}
	public void addMerchant(Merchant merchant) {
		// TODO Auto-generated method stub
		merchantDao.save(merchant);
	}
	

	public List<Product> getProductByMerchant(String merchant) {
		
		return productRepo.getMerchantById(merchant);
	}
	
	public List<Product> getAllProducts(){
		
            return productRepo.findAll();
        
	}
	public List<Merchant> getAllMerchants(){
		
        return merchantDao.findAll();
    
}
	public List<Customer> getAllCustomers(){
		return customerRepo.findAll();
		
	}

    public void addtoCart(String custId, CartItem cart){
        Customer customer = findCustomerById(custId);
        List<CartItem> cartList = customer.getCartItems();
        cartList.add(cart);
        customerCartRepo.save(cart);
        customerRepo.save(customer);       
    }
   
    public List<CartItem> getCartProducts(String custId){
        Customer customer = findCustomerById(custId);
        List<CartItem> cartList = customer.getCartItems();
        return cartList;
    }
   
    public List<CartItem> deleteFromCart(String cartId) {
        customerCartRepo.deleteById(cartId);
        return customerCartRepo.findAll();
    }

}
