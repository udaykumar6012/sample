package com.capg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capg.bean.Product;

public interface CapgProductRepo extends JpaRepository<Product, String>  {
	@Query("from Product where MERCHANT_MERID=:pro")
	  List<Product>  getMerchantById(@Param("pro") String merId);
}
