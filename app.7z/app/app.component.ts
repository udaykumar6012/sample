import { Component } from '@angular/core';
import { DeprecatedI18NPipesModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'assignment2';
  
  upid: any;
  upname: any;
  upsal: any;
  updep: any;
  res: any;
  constructor (private httpService: HttpClient) { }
  Emps:any[];
  ngOnInit () {
    this.httpService.get('./assets/Emp.json').subscribe(
      data => {
        this.Emps = data as string [];	 // FILL THE ARRAY WITH DATA.
        //  console.log(this.arrBirds[1]);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }
  
    add(id1:number,name:string,sal:number,Dep:string){
    let bx1=id1;
    let bx2=name;
    let bx3=sal;
    let bx4=Dep;
    this.Emps.push({'empId':bx1,'empName':bx2,'empSal':bx3,'empDep':bx4})
}
   update(emp){
    this.upid=emp.empId;
    this.upname=emp.empName;
    this.upsal=emp.empSal;
    this.updep=emp.empDep;
    this.res=emp;
   }
   updateDetails(uid:number,uname:string,usal:number,udept:string)
 {
  this.res.empId=uid;
  this.res.empName=uname;
  this.res.empSal=usal;
  this.res.empDept=udept;
 }
 delete(index:number)
 {
   this.Emps.splice(index,1);
 }

}
