package com.cg.service;

public class ValidationClass
{

	public boolean checkName(String name) {
		String pattern1="[A-Z][a-z]*";
		if(name.matches(pattern1))
		    {
			return true;
			}
		else
			{
			return false;
			}
	}


	public boolean checkAdhaar(String adhaarNo)
	{
		if(adhaarNo.length()==12)
		{
			return true;
		}
		else {
			return false;
		}
	}


	public boolean checkNumber(String mobileNumber) {
		String pattern="[7-9][0-9]{9}";
				if(mobileNumber.matches(pattern))
		     return true;
				else {
					return false;
				}
				
	}


	public boolean setPin(String pin)
	{
		if(pin.length()==4)
		{
			return true;
		}
		else
		{
		return false;
		}
	}


}
