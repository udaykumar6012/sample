package com.service;



import java.sql.ResultSet;

import com.bean.Bean;
import com.dao.AccountDao;

public class AccountService {

	AccountDao ad = new AccountDao();


	public boolean validateAccount(int acc) 
	{
		return ad.validateAccount(acc);
	}
	public void createAccount(Bean bean)
	{
		ad.createAccount(bean);
	}

public double showBalance(int accountId)
	{
	
		return ad.showBalance(accountId);
	}

	public double depositAmount(int accountId1, double depositAmount) 
	{
		return ad.depositAmount(accountId1, depositAmount);
	}

	public double withdrawAmount(int accountId2, double withdrawAmount)
	{
		return ad.withdrawAmount(accountId2, withdrawAmount);
	}
	
	
	public void cashTransfer(int source, int destination, double money) 
	{
	
		 ad.cashTransfer(source,destination,money);
	}
	
		public ResultSet getTransaction(int accountNumber)
		{
	        return ad.getTransactions(accountNumber);
	    }
	


	}

