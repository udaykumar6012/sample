package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.bean.Bean;



public class AccountDao 
{
	 String URL= "JDBC:oracle:thin:@localhost:1521:XE";
	 
	public Connection establishConnection()	
	{
		   Connection connect = null;
		 try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
	
			e.printStackTrace();
		}
	  
		try {
			connect = DriverManager.getConnection(URL,"system","orcl11g");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return connect;
	        
	}
	public boolean validateAccount(int accountId)
	{
		Connection con=establishConnection();
		int num=0;
		try {
			PreparedStatement statement=con.prepareStatement("select accountNumber from Bank where accountnumber=?");
			statement.setInt(1, accountId);	
			ResultSet value=statement.executeQuery();
			while(value.next())
			num=value.getInt("accountNumber");
			if(num!=0)
				return true;	
			}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return false;
		
	}

	public void createAccount(Bean bean)
	{
		Connection con=establishConnection();
		try {
			PreparedStatement statement=con.prepareStatement("insert into Bank values(?,?,?,?)");
			PreparedStatement state=con.prepareStatement("insert into Transactions values(?,?,?,?)");
		
			statement.setInt(1, bean.getAccountNumber());
			statement.setString(2, bean.getName());
			statement.setDouble(3, bean.getBalance());
			statement.setString(4, bean.getPhoneNumber());
			statement.executeQuery();
			
			state.setInt(1, bean.getAccountNumber());
			state.setInt(2, 0);
			state.setInt(3, 0);
			state.setDouble(4, bean.getBalance());
			state.executeQuery();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	public double showBalance(int accountId)
	{
		double balance=0;
		
		Connection con=establishConnection();
		try {
			PreparedStatement statement=con.prepareStatement("select Balance from Bank where accountnumber=?");
			
			statement.setInt(1, accountId);			
		ResultSet value=statement.executeQuery();
		while(value.next())
		balance=value.getDouble("Balance");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return balance;
	}
	
	public double depositAmount(int accountId1, double depositAmount)
	{
	
	double deposit=0;
		Connection con=establishConnection();
		try {
			double Amount=showBalance(accountId1)+depositAmount;
			PreparedStatement statement=con.prepareStatement("update Bank set Balance=? where accountNumber=?");
			PreparedStatement state=con.prepareStatement("insert into Transactions values(?,?,?,?)");
			statement.setDouble(1,Amount);
			statement.setInt(2,accountId1);
			statement.executeQuery();
			deposit=showBalance(accountId1);
			
			state.setInt(1, accountId1);
			state.setDouble(2, depositAmount);
			state.setDouble(3, 0);
			state.setDouble(4,Amount);
			state.executeQuery();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	return deposit;
	}
	
	public double withdrawAmount(int accountId2, double withdrawAmount)
	{
		double withdraw=0;
		
		
		Connection con=establishConnection();
		try {
			double Amount=showBalance(accountId2)-withdrawAmount;
			PreparedStatement statement=con.prepareStatement("update Bank set Balance=? where accountNumber=?");
			PreparedStatement state=con.prepareStatement("insert into Transactions values(?,?,?,?)");
			
			statement.setDouble(1,Amount);
			statement.setInt(2,accountId2);
			statement.executeQuery();
			withdraw=showBalance(accountId2);
			
			state.setInt(1, accountId2);
			state.setDouble(2, 0);
			state.setDouble(3, withdrawAmount);
			state.setDouble(4,Amount);
			state.executeQuery();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	return withdraw;
	}
	
	public void cashTransfer(int source, int destination, double money)
	{
		Connection con=establishConnection();
		
		try {
			double Amount=showBalance(source)-money;
			PreparedStatement statement=con.prepareStatement("update Bank set Balance=? where accountNumber=?");
			PreparedStatement state=con.prepareStatement("insert into Transactions values(?,?,?,?)");
			statement.setDouble(1,Amount);
			statement.setInt(2,source);		
			statement.executeQuery();
			
			state.setInt(1,source);
			state.setDouble(2, 0);
			state.setDouble(3, money);
			state.setDouble(4,Amount);
			state.executeQuery();
		}
		 catch (SQLException e) 
		{
			e.printStackTrace();
		}
		try {	
		double Amount=showBalance(destination)+money;
			PreparedStatement statement=con.prepareStatement("update Bank set Balance=? where accountNumber=?");
			PreparedStatement state=con.prepareStatement("insert into Transactions values(?,?,?,?)");
			statement.setDouble(1,Amount);
			statement.setInt(2,destination);
			statement.executeQuery();
			
			state.setInt(1,destination);
			state.setDouble(2, money);
			state.setDouble(3, 0);
			state.setDouble(4,Amount);
			state.executeQuery();
		}
		 catch (SQLException e) 
		{
			e.printStackTrace();
		}
	
	}
		public ResultSet getTransactions(int accountId)
	{			ResultSet rs=null;
			try {
				Connection con=establishConnection();
			PreparedStatement statement=con.prepareStatement("select * from Transactions where accountNumber=?");
			statement.setDouble(1,accountId);
			rs=statement.executeQuery();		
			}
			 catch (SQLException e) 
			{
				e.printStackTrace();
			}
			return rs;
	}
}