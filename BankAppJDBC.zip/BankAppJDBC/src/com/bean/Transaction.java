package com.bean;

public class Transaction 
{
private int AccountNumber;
private double credit;
private double debit;
private double bal;
public int getAccountNumber() {
	return AccountNumber;
}
public void setAccountNumber(int accountNumber) {
	AccountNumber = accountNumber;
}
public double getCredit() {
	return credit;
}
public void setCredit(double credit) {
	this.credit = credit;
}
public double getDebit() {
	return debit;
}
public void setDebit(double debit) {
	this.debit = debit;
}
public double getBal() {
	return bal;
}
public void setBal(double bal) {
	this.bal = bal;
}
@Override
public String toString() {
	return "Transaction [AccountNumber=" + AccountNumber + ", credit=" + credit + ", debit=" + debit + ", bal=" + bal
			+ "]";
}

}
