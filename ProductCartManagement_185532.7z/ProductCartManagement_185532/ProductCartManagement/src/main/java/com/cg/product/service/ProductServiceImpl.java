package com.cg.product.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.product.bean.Product;
import com.cg.product.dao.IProductRepo;
import com.cg.product.exception.ProductException;
/***
* Author : Uday kumar M
* Date of Creation : 30-July-2019
* Purpose : To have a service layered representaion
*/
@Service
public class ProductServiceImpl implements IProductService{
	@Autowired
	IProductRepo productDao;
	/***
	* Author :Uday kumar M
	* Date of Creation : 30-July-2019
	* Method Name : createproduct
	* Parameters : Product Object
	* Return Value : Returns a list of Products
	* Purpose : To create a product in the product database
	*/
	@Override
	public List<Product> createproduct(Product pro) throws ProductException {
		try {
			productDao.save(pro);
			return productDao.findAll();
		}
		catch (Exception ex) {
			// TODO: handle exception
			throw new ProductException(ex.getMessage());
		}

	}
	/***
	* Author : Uday kumar M
	* Date of Creation : 30-July-2019
	* Method Name :get product by id
	* Return Value : Returns the product id details
	* Purpose : To return the details of product
	*/
	@Override
	public Product getProductById(String id) throws ProductException {

		try {
			return  productDao.findById(id).get();
		}
		catch (Exception ex) {
			throw new ProductException(ex.getMessage());
		}
	}

	/***
	* Author : Uday kumar M
	* Date of Creation : 30-July-2019
	* Method Name :delete product
	* Parameters : string type
	* Return Value : null deletes the required detail
	* Purpose : To delete the required detail
	*/
	@Override
	public void deleteProduct(String id) throws ProductException {
		try {
			productDao.deleteById(id);
		}
		catch (Exception ex) {
			throw new ProductException(ex.getMessage());
		}

	}

	/***
	* Author : Uday kumar M
	* Date of Creation : 30-July-2019
	* Method Name :get all products
	* Return Value : Returns the all product values
	* Purpose : To get all product details
	*/
	@Override
	public List<Product> getAllProducts() throws ProductException {

		try{
			return productDao.findAll();
		}
		catch (Exception ex) {
			throw new ProductException(ex.getMessage());
		}
	}

	/***
	* Author :Uday kumar M
	* Date of Creation : 30-July-2019
	* Method Name :update product
	* Parameters : product object
	* Return Value : returns list of product
	* Purpose : To update product details
	*/
	@Override
	public List<Product> updateProduct(Product pro) throws ProductException {

		try
		{
			productDao.save(pro);
			return productDao.findAll();
		}
		catch (Exception ex) {
			// TODO: handle exception
			throw new ProductException(ex.getMessage());
		}
	}

}
