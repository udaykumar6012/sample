package com.cg.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.product.bean.Product;
import com.cg.product.exception.ProductException;
import com.cg.product.service.IProductService;

@RestController
public class ProductController {

	@Autowired
	IProductService productService;
	
	@RequestMapping("/products")
    public List<Product>  getAllProducts() throws ProductException
    {
        return productService.getAllProducts();
    }
	
	
	@RequestMapping(value="/products", method = RequestMethod.POST)
    public List<Product> createproduct(@RequestBody Product prod) throws ProductException
    {
        return productService.createproduct(prod);
    }
	
	
	@RequestMapping("/products/{id}")
    public Product findProductById(@PathVariable String id) throws ProductException{
        return productService.getProductById(id);
    }
	
	
	@RequestMapping(value="/products/{id}", method= RequestMethod.DELETE)
    public ResponseEntity<String> deleteProducts(@PathVariable String id) throws ProductException{
    	productService.deleteProduct(id);
		return new ResponseEntity<String>("product with "+id+"deleted",HttpStatus.OK);
    }
	
	 
	 @RequestMapping(value="/products/{id}", method=RequestMethod.PUT)
	 public ResponseEntity<String> updateProduct(@RequestBody Product pro) throws ProductException {
	 	   productService.updateProduct(pro);
	 	   return new ResponseEntity<String>("Product Successfully updated", HttpStatus.OK);
	 }
	@ExceptionHandler(ProductException.class)
	public ResponseEntity<String> handleProductExceptions(Exception ex) {
		return new ResponseEntity<String>("Error: " + ex.getMessage(),HttpStatus.CONFLICT);
	}
}
