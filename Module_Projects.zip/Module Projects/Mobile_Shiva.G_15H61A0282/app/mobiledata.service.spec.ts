import { TestBed } from '@angular/core/testing';

import { MobiledataService } from './mobiledata.service';

describe('MobiledataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MobiledataService = TestBed.get(MobiledataService);
    expect(service).toBeTruthy();
  });
});
