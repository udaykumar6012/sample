import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable,throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class MobiledataService {

  constructor(private http:HttpClient) { }

  url:string="/assets/data/mobile.json";

  getMobiles() : Observable<Mobile> {
    
    return this.http.get<Mobile>(this.url)
 
    .pipe(catchError(this.errorHandler));
     
   }
 
   errorHandler(error:HttpErrorResponse){
 
       return throwError(error.message || " Service error ");
 
   }
   
 
    
}
  






class Mobile{

  mobId:number;
  mobName:string;
  mobPrice:number;
 
}

