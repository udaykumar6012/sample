import { Component } from '@angular/core';
import { MobiledataService } from './mobiledata.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Mobile Application';


  
private mobList:any=[];

constructor( private _service:MobiledataService ) {

 }
 ngOnInit() {
   
  this._service.getMobiles().subscribe(data => this.mobList=data);
}

deleteMobile(i){
  this.mobList.splice(i,1);
  alert("Deleted");
}

idSort(){
  console.log("sort is called");
  this.mobList=this.mobList.sort(function(a,b){
    return a.mobId-b.mobId;
    })
}

nameSort(){
  console.log("sort is called");
    this.mobList=this.mobList.sort(function(a,b){
      return a.mobName.localeCompare(b.mobName)
    })
}


priceSort(){
  console.log("sort is called");
    this.mobList=this.mobList.sort(function(a,b){
      return a.mobPrice-b.mobPrice;
    })
  
}
}
