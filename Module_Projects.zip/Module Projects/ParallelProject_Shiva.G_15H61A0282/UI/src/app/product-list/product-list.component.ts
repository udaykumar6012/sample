import { Component, OnInit } from '@angular/core';
import {ProductService} from '../product.service'
import { Product } from '../product';
import { Range } from '../range';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  
product=new Product();
productList:Product[];
productId:number;
type:string="All";
range = new Range();
searchText:any;

  constructor(private _service:ProductService) { }

  ngOnInit() {
   this._service.getAllProdcutsList().subscribe((data)=>this.productList=data);
  }

//*********************************************** Product Page Module ************************************************ */

  getProducts(type:string):void{
    this._service.getProducts(this.product.productType).subscribe((productData:any)=>{this.productList=productData,console.log(productData)},error=>console.log(error));
    this.type=this.product.productType;
  }
  getProductById(id:number):void{
    
this._service.setUser(id);

  }
//************************************* Sorting Module*************************************************//


  sortByAssending(){     
       this.productList=this.productList.sort(function(a,b){
        return a.productPrice-b.productPrice;
       })
  }
  sortByDescending(){
    this.productList=this.productList.sort(function(a,b){
         return b.productPrice-a.productPrice;
    })
  }
  sortByRange(low:number,high:number){
    console.log(low,high);
    this._service.getProductListByRange(low,high,this.type).subscribe(data=>this.productList=data);
  }
  sortByBestSeller(){
    this.productList=this.productList.sort(function(a,b){
      return a.productAvgRating-b.productAvgRating;
    })
  }
  sortByViews(){
    this.productList=this.productList.sort(function(a,b){
      return a.productAvgRating-b.productAvgRating;
    })
  }


  
/////////////////////////////////////////////////////////
  getWishList(userId:number){
    this._service.getWishlist(userId).subscribe((productData:any)=>{this.productList=productData,console.log(productData)},error=>console.log(error));
  }
}
