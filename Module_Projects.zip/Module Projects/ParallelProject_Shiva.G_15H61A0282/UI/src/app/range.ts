export class Range{

    low:number;
    high:number;
}