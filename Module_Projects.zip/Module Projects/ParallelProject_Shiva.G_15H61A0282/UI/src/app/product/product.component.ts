import { Component, OnInit, Input } from '@angular/core';
import { ProductService } from '../product.service'
import { Product } from '../product';
import { Feedback } from '../feedback';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  //template:'{{productId}}',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  @Input() event: number;
  product = new Product();
  productList: Product[];
  feedbackList: Feedback[];
  userId: number;
  type: string;
  buffer: any;
  len: number = 0;

  length: number = 50;

  productRating: number[] = [0, 0, 0, 0, 0];

  getLength(): number {
    return this.length;
  }
  constructor(private _service: ProductService) { }

  ngOnInit() {
    this.getUser();
  }

  getProductById(id: number): void {

    this._service.getProductById(id).subscribe((productData: any) => { this.product = productData, console.log(productData) }, error => console.log(error));
    this.getFeedbackById(id);
  }
  getUser() {
    this._service.currentUser.subscribe(user => { this.userId = user }, error => { console.log(console.log(error)) });

    this.getProductById(this.userId);
  }


  addtoWishList(productId: number) {
    this.userId = 501;
    this._service.addtoWishList(productId, this.userId).subscribe((data) => alert("Product " + data + " is added to wish List"));
  }

  addtoCart(productId: number) {
    this.userId = 501;
    this._service.addtoCart(productId, this.userId).subscribe((data) => alert("Product " + data + " is added to Cart"));
  }

  getFeedbackById(id: number) {

    this._service.getFeedbackById(id).subscribe((feedbackData: any) => {
    this.feedbackList = feedbackData;
      for (let count of this.feedbackList) {
        //alert('called');
        if (count.rating > 4)
          this.productRating[0] += 1;
        else
          if (count.rating > 3)
            this.productRating[1] += 1;
          else
            if (count.rating > 2)
              this.productRating[2] += 1;
            else
              if (count.rating > 1)
                this.productRating[3] += 1;
              else
                if (count.rating > 0)
                  this.productRating[4] += 1;
      }

      this.len = this.feedbackList.length;

      this.productRating[0] = parseFloat(((this.productRating[0] / this.len) * 100).toFixed(2));
      this.productRating[1] = parseFloat(((this.productRating[1] / this.len) * 100).toFixed(2));
      this.productRating[2] = parseFloat(((this.productRating[2] / this.len) * 100).toFixed(2));
      this.productRating[3] = parseFloat(((this.productRating[3] / this.len) * 100).toFixed(2));
      this.productRating[4] = parseFloat(((this.productRating[4] / this.len) * 100).toFixed(2));

    }, error => console.log(error));



  }



  imageZoom(imgID, resultID) {
    var img, lens, result, cx, cy;
    img = document.getElementById(imgID);
    result = document.getElementById(resultID);
    /*create lens:*/
    lens = document.createElement("DIV");
    lens.setAttribute("class", "img-zoom-lens");
    /*insert lens:*/
    img.parentElement.insertBefore(lens, img);
    /*calculate the ratio between result DIV and lens:*/
    cx = result.offsetWidth / lens.offsetWidth;
    cy = result.offsetHeight / lens.offsetHeight;
    /*set background properties for the result DIV:*/
    result.style.backgroundImage = "url('" + img.src + "')";
    result.style.backgroundSize = (img.width * cx) + "px " + (img.height * cy) + "px";
    /*execute a function when someone moves the cursor over the image, or the lens:*/
    lens.addEventListener("mousemove", moveLens);
    img.addEventListener("mousemove", moveLens);
    /*and also for touch screens:*/
    lens.addEventListener("touchmove", moveLens);
    img.addEventListener("touchmove", moveLens);
    function moveLens(e) {
      var pos, x, y;
      /*prevent any other actions that may occur when moving over the image:*/
      e.preventDefault();
      /*get the cursor's x and y positions:*/
      pos = getCursorPos(e);
      /*calculate the position of the lens:*/
      x = pos.x - (lens.offsetWidth / 2);
      y = pos.y - (lens.offsetHeight / 2);
      /*prevent the lens from being positioned outside the image:*/
      if (x > img.width - lens.offsetWidth) { x = img.width - lens.offsetWidth; }
      if (x < 0) { x = 0; }
      if (y > img.height - lens.offsetHeight) { y = img.height - lens.offsetHeight; }
      if (y < 0) { y = 0; }
      /*set the position of the lens:*/
      lens.style.left = x + "px";
      lens.style.top = y + "px";
      /*display what the lens "sees":*/
      result.style.backgroundPosition = "-" + (x * cx) + "px -" + (y * cy) + "px";
    }
    function getCursorPos(e) {
      var a, x = 0, y = 0;
      e = e || window.event;
      /*get the x and y positions of the image:*/
      a = img.getBoundingClientRect();
      /*calculate the cursor's x and y coordinates, relative to the image:*/
      x = e.pageX - a.left;
      y = e.pageY - a.top;
      /*consider any page scrolling:*/
      x = x - window.pageXOffset;
      y = y - window.pageYOffset;
      return { x: x, y: y };
    }
  }
}
