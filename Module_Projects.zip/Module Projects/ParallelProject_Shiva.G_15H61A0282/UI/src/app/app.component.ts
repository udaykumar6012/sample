import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Capg Cart';
  public clickedEvent: number;

  childEventClicked(event: number) {
    this.clickedEvent = event;
  }
}
