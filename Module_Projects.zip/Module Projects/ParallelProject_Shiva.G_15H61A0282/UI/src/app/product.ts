export class Product
{
    productId:number;
    productName:string;
    productType:string;
    productPrice:number;
    productDesc:string;
    productImg:string;
    productAvgRating:number;
    
}