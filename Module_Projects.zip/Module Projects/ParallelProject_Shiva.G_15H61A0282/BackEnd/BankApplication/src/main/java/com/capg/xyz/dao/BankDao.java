package com.capg.xyz.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capg.xyz.exception.BalanceException;
import com.capg.xyz.exception.CustomerException;
import com.capg.xyz.model.CustomerDetails;
import com.capg.xyz.model.TransactionDetails;

@Repository
public class BankDao implements IBankDao {
	@Autowired
	BankRepo bankRepo;
	@Autowired
	TransactionsRepo transRepo;

	/*************************************************************************
	* Method name :  createAccount
	* parameter :  CustomerDetails b
	* Return Type : int
	* Author : 15H61A0282 
	* Description: create the account and returns account number
	*************************************************************************/
	@Override
	public int createAccount(CustomerDetails b) {

		b.setAccountNumber((int) (Math.random() * 10000));
		CustomerDetails bank = bankRepo.save(b);
		TransactionDetails t = new TransactionDetails();

		t.setTransactionId((long) (Math.random() * 1000));
		t.setAccountNumber(b.getAccountNumber());
		t.setTransactionType("credit");
		t.setAmount(b.getBalance());
		transRepo.save(t);
		return bank.getAccountNumber();
	}

	/*************************************************************************
	* Method name : showBalance
	* parameter :  int accNo
	* Return Type : long
	* Author : 15H61A0282 
	* Description: finds the account and returns balance
	*************************************************************************/
	@Override
	public long showBalance(int accNo) {
		
		try {
			CustomerDetails b = bankRepo.findById(accNo).orElse(null); 
			return  b.getBalance();
		}
		catch (NullPointerException e) {
			CustomerException exp = new CustomerException(accNo);
			return -1;
		}
	}

	/*************************************************************************
	* Method name : depositAmount
	* parameter :  int accountNumber, long depositedAmount
	* Return Type : CustomerDetails
	* Author : 15H61A0282 
	* Description: finds the account number and deposits the amount ,then return the customer details
	*************************************************************************/
	@Override
	public long depositAmount(int accountNumber, long depositedAmount) {
		
		TransactionDetails t = new TransactionDetails();
		try {
		CustomerDetails bank = bankRepo.findById(accountNumber).orElse(null);
		
		long balance = bank.getBalance() + depositedAmount;
		bank.setBalance(balance);
		t.setTransactionId((long) (Math.random() * 1000));
		t.setAccountNumber(accountNumber);
		t.setTransactionType("credit");
		t.setAmount(depositedAmount);
		CustomerDetails b = bankRepo.save(bank);
		transRepo.save(t);
		return b.getBalance();
		
		}catch (NullPointerException e) {
			CustomerException exp = new CustomerException(accountNumber);
			return -2;
		}
		
	}
	/*************************************************************************
	* Method name : withdrawAmount
	* parameter :  int accountNumber, long withdrawAmount
	* Return Type : CustomerDetails
	* Author : 15H61A0282 
	* Description: finds the account number and withdraw the amount ,then return the customer details
	* *************************************************************************/
	@Override
	public long withdrawAmount(int accountNumber, long withdrawAmount) {
		TransactionDetails t = new TransactionDetails();
		try {
		CustomerDetails bank = bankRepo.findById(accountNumber).orElse(null);
		
		
			if(bank.getBalance()>=withdrawAmount) {
				long balance = bank.getBalance() - withdrawAmount;
				bank.setBalance(balance);
				t.setTransactionId((long) (Math.random() * 1000));
				t.setAccountNumber(accountNumber);
				t.setTransactionType("debit");
				t.setAmount(withdrawAmount);
				transRepo.save(t);
				CustomerDetails b = bankRepo.save(bank);
				return b.getBalance();
			}
			else {
				BalanceException exp = new BalanceException();
				long temp=-1;
				return temp;
			}
	
		
		}catch (NullPointerException e) {
			CustomerException exp = new CustomerException(accountNumber);
			return -2;
		}
	}

	/*************************************************************************
	* Method name : fundTransfer
	* parameter :  int senderAccNo, int recieverAccNo, long amount
	* Return Type : CustomerDetails
	* Author : 15H61A0282 
	* Description: transfer amount from sender to receiver
	*************************************************************************/
	@Override
	public long fundTransfer(int senderAccNo, int recieverAccNo, long amount) {
		
		TransactionDetails t = new TransactionDetails();
		try {
		CustomerDetails bank = bankRepo.findById(senderAccNo).orElse(null);
		CustomerDetails bank2 = bankRepo.findById(recieverAccNo).orElse(null);

			if(bank.getBalance()>=amount) {
			
				long balance = bank.getBalance() - amount;
				bank.setBalance(balance);
				t.setTransactionId((long) (Math.random() * 1000));
				t.setAccountNumber(senderAccNo);
				t.setTransactionType("debit");
				t.setAmount(amount);
				transRepo.save(t);
				CustomerDetails b = bankRepo.save(bank);	
		
				balance = bank2.getBalance() + amount;
				bank2.setBalance(balance);
				t.setTransactionId((long) (Math.random() * 1000));
				t.setAccountNumber(recieverAccNo);
				t.setTransactionType("credit");
				t.setAmount(amount);
				transRepo.save(t);
				bankRepo.save(bank2);
		
				return b.getBalance();
				}
			else {
				BalanceException exp = new BalanceException();
				long temp=-1;
				return temp;
			}
		
		}catch (NullPointerException e) {
			CustomerException exp = new CustomerException(senderAccNo);
			return -2;
		}
		
	}

	/*************************************************************************
	* Method name : printTransactions
	* parameter :  int accouNum
	* Return Type : List<TransactionDetails> 
	* Author : 15H61A0282 
	* Description: finds the transactions list and return it 
	*************************************************************************/
	@Override
	public List<TransactionDetails> printTransaction(int accouNum) {
		
		List<TransactionDetails> tList = transRepo.findAllByAccountNumber(accouNum);
		if(tList.size()==0) {
			
			CustomerException exp = new CustomerException(accouNum);
			return null;
		}
		else {
		return transRepo.findAllByAccountNumber(accouNum);
		}

		
	}

}