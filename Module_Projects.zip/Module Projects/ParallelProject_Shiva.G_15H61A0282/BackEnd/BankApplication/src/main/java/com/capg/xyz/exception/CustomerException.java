package com.capg.xyz.exception;

public class CustomerException  extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomerException(int id) {
		super("ID Not Found, Wrong Id="+id);
	}

	public CustomerException() {
		
	}
	
}
