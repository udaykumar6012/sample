package com.capg.xyz.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.xyz.model.TransactionDetails;

public interface TransactionsRepo extends JpaRepository<TransactionDetails, Integer> {
	
	
	List<TransactionDetails> findAllByAccountNumber(int accountNumber);
}
