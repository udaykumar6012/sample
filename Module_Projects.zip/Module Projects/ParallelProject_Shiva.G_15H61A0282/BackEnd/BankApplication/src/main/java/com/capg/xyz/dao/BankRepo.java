package com.capg.xyz.dao;

import org.springframework.data.repository.CrudRepository;

import com.capg.xyz.model.CustomerDetails;

public interface BankRepo extends CrudRepository<CustomerDetails, Integer>{

	

}
