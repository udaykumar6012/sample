package com.capg.xyz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.xyz.dao.IBankDao;
import com.capg.xyz.model.CustomerDetails;
import com.capg.xyz.model.TransactionDetails;

@Service
public class BankService implements IBankService {
	@Autowired
	IBankDao dao;


	/*************************************************************************
	* Method name :  createAccount
	* parameter :  CustomerDetails b
	* Return Type : int
	* Author : 15H61A0282 
	* Description: create the account and returns account number
	*************************************************************************/
	@Override
	public int createAccount(CustomerDetails b) {
		return dao.createAccount(b);
	}

	/*************************************************************************
	* Method name : showBalance
	* parameter :  int accNo
	* Return Type : long
	* Author : 15H61A0282 
	* Description: finds the account and returns balance
	*************************************************************************/
	@Override
	public long showBalance(int accNo) {

		return dao.showBalance(accNo);
	}
	/*************************************************************************
	* Method name : depositAmount
	* parameter :  int accountNumber, long depositedAmount
	* Return Type : CustomerDetails
	* Author : 15H61A0282 
	* Description: finds the account number and deposits the amount ,then return the customer details
	*************************************************************************/
	@Override
	public long depositAmount(int accNumber, long depositedAmount) {
		return dao.depositAmount(accNumber, depositedAmount);
	}

	/*************************************************************************
	* Method name : withdrawAmount
	* parameter :  int accountNumber, long withdrawAmount
	* Return Type : CustomerDetails
	* Author : 15H61A0282 
	* Description: finds the account number and withdraw the amount ,then return the customer details
	* *************************************************************************/
	@Override
	public long withdrawAmount(int accountNumber, long withdrawAmount) {
		return dao.withdrawAmount(accountNumber, withdrawAmount);

	}
	/*************************************************************************
	* Method name : fundTransfer
	* parameter :  int senderAccNo, int recieverAccNo, long amount
	* Return Type : CustomerDetails
	* Author : 15H61A0282 
	* Description: transfer amount from sender to receiver
	*************************************************************************/
	@Override
	public long fundTransfer(int senderAccno, int recieverAccNo, long amount) {
		return dao.fundTransfer(senderAccno, recieverAccNo, amount);

	}

	/*************************************************************************
	* Method name : printTransactions
	* parameter :  int accouNum
	* Return Type : List<TransactionDetails> 
	* Author : 15H61A0282 
	* Description: finds the transactions list and return it 
	*************************************************************************/
	@Override
	public List<TransactionDetails> printTransactions(int accouNum) {

		return dao.printTransaction(accouNum);
	}

}
