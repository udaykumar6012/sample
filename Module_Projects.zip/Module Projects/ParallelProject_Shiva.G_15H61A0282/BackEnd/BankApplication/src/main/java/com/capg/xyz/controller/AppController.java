package com.capg.xyz.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.xyz.model.CustomerDetails;
import com.capg.xyz.model.TransactionDetails;
import com.capg.xyz.service.IBankService;

@CrossOrigin("*")
@RestController
public class AppController {

	@Autowired
	private IBankService service;

	
	/*************************************************************************
	* Method name : create
	* parameter   : CustomerDetails b
	* Return Type : int
	* Author      : 15H61A0282 
	* Description : return the account number 
	*************************************************************************/
	@PostMapping(path = "/create", consumes = "application/json")
	public int create(@RequestBody CustomerDetails b) {
		int accNo=service.createAccount(b);
		return accNo;
	}

	/*************************************************************************
	* Method name : balance
	* parameter :  int accNo
	* Return Type : long
	* Author : 15H61A0282 
	* Description: return balance
	*************************************************************************/
	@GetMapping(path = "/showbalance/{accNo}", produces = "application/json")
	public long balance(@PathVariable int accNo) {
		return service.showBalance(accNo);
	}
	/*************************************************************************
	* Method name : depositAmount
	* parameter :  int accNo,long depositAmount
	* Return Type : CustomerDetails
	* Author : 15H61A0282 
	* Description: returns CustomerDetails
	*************************************************************************/
	@PostMapping(path = "/deposit/{accNo}/{depositAmount}", consumes = "application/json")
	public long depositAmount(@PathVariable int accNo, @PathVariable long depositAmount) {
		
		return service.depositAmount(accNo, depositAmount);
	}

	/*************************************************************************
	* Method name : withdrawAmount
	* parameter :  int accNo,long withdrawAmount
	* Return Type : CustomerDetails
	* Author : 15H61A0282 
	* Description: returns customerdetails
	*************************************************************************/
	@PostMapping(path = "/withdraw/{accNo}/{withdrawAmount}", consumes = "application/json")
	public long withdrawAmount(@PathVariable int accNo, @PathVariable long withdrawAmount) {
		
		return service.withdrawAmount(accNo, withdrawAmount);
	}

	/*************************************************************************
	* Method name : fundTransfer
	* parameter :  int senderAccNo, int recieverAccNo,long amount
	* Return Type : CustomerDetails
	* Author : 15H61A0282 
	* Description: returns CustomerDetails
	*************************************************************************/
	@PostMapping(path = "/fundtransfer/{senderAccNo}/{recieverAccNo}/{amount}", consumes = "application/json")
	public long fundTransfer(@PathVariable int senderAccNo, @PathVariable int recieverAccNo,
			@PathVariable long amount) {
		return service.fundTransfer(senderAccNo, recieverAccNo, amount);
	}

	/*************************************************************************
	* Method name : showTransaction
	* parameter :  int accNo
	* Return Type : List<transactionDetails>
	* Author : 15H61A0282 
	* Description: returns transaction list
	*************************************************************************/
	@GetMapping(path = "/transactions/{accNo}", produces = "application/json")
	public List<TransactionDetails> showTransaction(@PathVariable int accNo) {

		return service.printTransactions(accNo);
	}

}
