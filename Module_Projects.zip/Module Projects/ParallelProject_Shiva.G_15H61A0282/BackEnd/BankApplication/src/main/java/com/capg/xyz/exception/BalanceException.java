package com.capg.xyz.exception;

public class BalanceException  extends RuntimeException {

	private static final long serialVersionUID = 1L;


	public BalanceException() {
		System.out.println("Insufficient Funds");
	}
	
}
