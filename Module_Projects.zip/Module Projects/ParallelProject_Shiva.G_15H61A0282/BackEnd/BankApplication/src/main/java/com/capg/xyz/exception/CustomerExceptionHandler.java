package com.capg.xyz.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class CustomerExceptionHandler {
	@ExceptionHandler
	public ResponseEntity<ErrorResponse> handleError(CustomerException exception, WebRequest req) {
		ErrorResponse eResponse = new ErrorResponse(new Date(), exception.getMessage(), req.getDescription(false));
		return new ResponseEntity<ErrorResponse>(eResponse, HttpStatus.NOT_FOUND);

	}

}
