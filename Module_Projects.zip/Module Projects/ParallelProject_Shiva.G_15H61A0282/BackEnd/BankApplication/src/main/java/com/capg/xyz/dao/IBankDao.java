package com.capg.xyz.dao;

import java.util.List;

import com.capg.xyz.model.CustomerDetails;
import com.capg.xyz.model.TransactionDetails;

public interface IBankDao {
	public abstract int createAccount(CustomerDetails b);

	public abstract long showBalance(int accNo);

	public abstract long depositAmount(int accNumber, long depositedAmount);

	public abstract long withdrawAmount(int accountNumber, long withdrawAmount);

	public abstract long fundTransfer(int senderAccNo, int recieverAccNo, long balance);

	public abstract List<TransactionDetails> printTransaction(int accouNum);

	
}
