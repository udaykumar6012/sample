package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.Map;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.CustomerException;

public class LoanDao implements ILoanDao {

	Customer c = new Customer();
	Loan l = new Loan();
	static Map<Long, Loan> loanEntry = new HashMap<Long, Loan>();
	static Map<Long, Customer> customerEntry = new HashMap<Long, Customer>();
	/*************************************************************************
	* Method name   : applyLoan
	* Parameter     : loan  
	* Return Type   : Long
	* Throws        : CustomerException 
	* Author        : 15H61A0282 
	* Creation Date : 08-march-2019 
	* Description   : adds the loan details to the database
	*************************************************************************/
	@Override
	public long applyLoan(Loan loan)throws CustomerException {

		loanEntry.put(loan.getLoanID(), loan);

		return loan.getLoanID();
	}
	/*************************************************************************
	* Method name   : insertCust
	* Parameter     : cust  
	* Return Type   : Long
	* Throws        : CustomerException 
	* Author        : 15H61A0282 
	* Creation Date : 08-march-2019 
	* Description   : adds the customer details to the database
	*************************************************************************/
	@Override
	public long insertCust(Customer cust)throws CustomerException {

		customerEntry.put(cust.getCustId(), cust);
		
		return cust.getCustId();
	}

}
