package com.capgemini.xyz.testing;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.ILoanDao;
import com.capgemini.xyz.dao.LoanDao;
import com.capgemini.xyz.exception.CustomerException;

public class LoanDaoTest {
	Loan l = new Loan();
	Customer c = new Customer();
	ILoanDao dao = new LoanDao();

	@Ignore
	@Test
	public void testApplyLoan() {

		try {
			assertEquals(105L, dao.applyLoan(l));
		} catch (CustomerException e) {

			e.loanException();
		}
		try {
			assertNotSame(0, dao.applyLoan(l));
		} catch (CustomerException e) {

			e.loanException();
		}
	}

	@Test
	public void testInsertCust() {

		try {
			assertNotSame(0, dao.insertCust(c));
		} catch (CustomerException e) {

			e.insertException();
		}
		try {
			assertEquals(101L, dao.insertCust(c));
		} catch (CustomerException e) {

			e.insertException();
		}
	}

	@BeforeClass
	public void setData() {
		l.setLoanID(105);
		l.setCustId(101);
		l.setDuration(2);
		l.setLoanAmount(1245012);

		c.setCustId(101);
		c.setCustName("Shiva");
		c.setEmail("shiva@gmail.com");
	}

}