package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.CustomerException;
import com.capgemini.xyz.service.ILoanService;
import com.capgemini.xyz.service.LoanService;

public class ExecuterMain {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Customer c = new Customer();
		ILoanService service = new LoanService();
		Loan l = new Loan();
		while (true) {
			System.out.println("XYZ Finance company welcomes you");
			System.out.println("1.Register Customer\n2.Exit");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				/*Reading the customer Data*/
				System.out.println("Enter Customer Name");
				String name = sc.next();
				System.out.println("Enter Address");
				String address = sc.next();
				System.out.println("Enter EMail");
				String email = sc.next();
				long cId = (long) (Math.random() * 10000);
				/*Setting the customer data to customer bean*/
				c.setCustId(cId);
				c.setCustName(name);
				c.setAddress(address);
				c.setEmail(email);
				boolean isValid = false;
				try {
					/*Invoking validateCustomer method in service class for validation of the input*/
					isValid = service.validateCustomer(c);
				} catch (CustomerException e1) {

					e1.validationException();
				}
				if (isValid) {

					long id = 0;
					try {
						/*Invoking insertCust method in service class for adding Customer information */
						id = service.insertCust(c);
					} catch (CustomerException e1) {
						e1.insertException();
					}
					if (id > 0) {
						System.out.println("Customer information saved successfully.\n Your Customer ID is " + id);
						System.out.println("Do you  wish to apply for Loan?(yes/no) ");
						String choice2 = sc.next();
						if (choice2.equalsIgnoreCase("yes")) {
							/* Reading data for applying loan */
							System.out.println("Enter the Loan amount");
							double amount = sc.nextDouble();
							System.out.println("Enter the duration");
							int duration = sc.nextInt();
							double emi = 0;
							try {
								/*Invoking calculateEMI method in service class for EMI calculation */
								emi = service.calculateEMI(amount, duration);
							} catch (CustomerException e) {

								e.emiException();
							}
							/*Checking for confirmation to apply for loan*/
							System.out.println("For loan amount " + amount + " and  " + duration + " Years duration");
							System.out.println("your EMI per month will be " + emi);
							System.out.println("Do you  wish to apply for Loan now?(yes/no) ");
							String choice3 = sc.next();
							if (choice3.equalsIgnoreCase("yes")) {
								/*Setting the loan data to bean*/
								long lId = (long) (Math.random() * 10000);
								l.setLoanID(lId);
								l.setCustId(c.getCustId());
								l.setDuration(duration);
								l.setLoanAmount(amount);
								long loanId = 0;
								try {
									/*Invoking applyLoan method in service class for generating loan */
									loanId = service.applyLoan(l);
								} catch (CustomerException e) {

									e.loanException();
								}
								if (loanId > 0) {
									/*Displaying the output*/
									System.out.println("Your loan request is generated");
									System.out.println("Your Loan ID is " + loanId);
									System.out.println("\nCustomer Details\n");
									System.out.println(c.toString());
									System.out.println(l.toString());
								} else {
									System.out.println(c.toString());
									System.err.println("Unable to Generate Loan");
								}
							} else {
								System.out.println(c.toString());
							}
						}
					}

				}

				break;

			case 2:
				System.exit(0);
				break;

			default:
				System.out.println("Wrong Choice");
				break;
			}

		}

	}
}
