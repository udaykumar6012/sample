package com.capgemini.xyz.exception;

public class CustomerException extends Exception {

	public void validationException() {
	
	System.err.println("Validation Exception");	
	}

	public void insertException() {
		
		System.err.println("Unable to insert the Customer");	
	}

	public void emiException() {
		
		System.err.println("Unable to calculate the Exception");	
	}

	public void loanException() {
		
		System.err.println("Unable to apply the loan");	
	}

}
