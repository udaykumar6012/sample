package com.capgemini.xyz.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.ILoanDao;
import com.capgemini.xyz.dao.LoanDao;
import com.capgemini.xyz.exception.CustomerException;

public class LoanService implements ILoanService {
	ILoanDao dao=new LoanDao();
	/*************************************************************************
	* Method name   : applyLoan
	* Parameter     : loan  
	* Return Type   : Long
	* Throws        : CustomerException 
	* Author        : 15H61A0282 
	* Creation Date : 08-march-2019 
	* Description   : adds the loan details to the database
	*************************************************************************/
	@Override
	public long applyLoan(Loan loan) throws CustomerException{
		
		return dao.applyLoan(loan);
	}
	/*************************************************************************
	* Method name   : validateCustomer
	* Parameter     : cust  
	* Return Type   : boolean
	* Throws        : CustomerException 
	* Author        : 15H61A0282 
	* Creation Date : 08-march-2019 
	* Description   : Validates the customer details from input
	*************************************************************************/
	@Override
	public boolean validateCustomer(Customer customer) throws CustomerException{
		boolean flag = true;

		Pattern p1 = Pattern.compile("[A-Za-z]{4,20}");
		Matcher m1 = p1.matcher(customer.getCustName());
		Pattern p2 = Pattern.compile("[A-Za-z]{4,20}");
		Matcher m2 = p2.matcher(customer.getAddress());

		if (!m1.find()) {
			flag = false;
			System.err.println("Customer Name is Invalid");
		}
		else if(!m2.find()){
			flag = false;
			System.err.println("Address is Invalid");
		}

		return flag;
	}
	/*************************************************************************
	* Method name   : insertCust
	* Parameter     : cust  
	* Return Type   : Long
	* Throws        : CustomerException 
	* Author        : 15H61A0282 
	* Creation Date : 08-march-2019 
	* Description   : adds the customer details to the database
	*************************************************************************/
	@Override
	public long insertCust(Customer cust) throws CustomerException{
		
		return dao.insertCust(cust);
	}
	/*************************************************************************
	* Method name   : calculateEMI
	* Parameter     : amount and duration 
	* Return Type   : double
	* Throws        : CustomerException 
	* Author        : 15H61A0282 
	* Creation Date : 08-march-2019 
	* Description   : calculates the EMI
	*************************************************************************/
	@Override
	public double calculateEMI(double amount, int duration) throws CustomerException{
		
		return amount * 0.095 * (1 + 0.095) * (duration * 12) / ((1 + 0.095) * (duration * 12) - 1);
	}

}
