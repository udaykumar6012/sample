package com.capgemini.pms.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "resources/Features", glue = "com.capgemini.pms.stepdefinition", plugin = {
		"html:target/cucumber_html_report" })
public class TestRunner {

}