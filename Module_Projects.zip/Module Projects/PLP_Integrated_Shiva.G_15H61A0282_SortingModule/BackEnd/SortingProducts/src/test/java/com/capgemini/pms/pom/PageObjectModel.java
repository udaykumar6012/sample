package com.capgemini.pms.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PageObjectModel {
	public static WebElement element = null;
	
	

	/*******************************************************************************
	 * -Function name : category
	 *  -Return type: WebElement 
	 *  -Parameters- WebDriver driver 
	 *  -Description: finds the webelement of category and returns it
	 ********************************************************************************/
	public static WebElement category(WebDriver driver) {

		element = driver.findElement(By.id("type"));
		return element;
	}


	/*******************************************************************************
	 * -Function name : categoryButton
	 *  -Return type: WebElement 
	 *  -Parameters- WebDriver driver 
	 *  -Description: finds the webelement of categoryButton and returns it
	 ********************************************************************************/
	public static WebElement categoryButton(WebDriver driver) {

		element = driver.findElement(By.id("categorybtn"));
		return element;
	}


	/*******************************************************************************
	 * -Function name : product
	 *  -Return type: WebElement 
	 *  -Parameters- WebDriver driver 
	 *  -Description: finds the webelement of product and returns it
	 ********************************************************************************/
	public static WebElement product(WebDriver driver) {

		element = driver.findElement(By.id("product"));
		return element;
	}
	

	/*******************************************************************************
	 * -Function name : low
	 *  -Return type: WebElement 
	 *  -Parameters- WebDriver driver 
	 *  -Description: finds the webelement of low and returns it
	 ********************************************************************************/
	public static WebElement low(WebDriver driver) {

		element = driver.findElement(By.id("low"));
		return element;
	}
	

	/*******************************************************************************
	 * -Function name : high
	 *  -Return type: WebElement 
	 *  -Parameters- WebDriver driver 
	 *  -Description: finds the webelement of high and returns it
	 ********************************************************************************/
	public static WebElement high(WebDriver driver) {

		element = driver.findElement(By.id("high"));
		return element;
	}
	

	/*******************************************************************************
	 * -Function name : price
	 *  -Return type: WebElement 
	 *  -Parameters- WebDriver driver 
	 *  -Description: finds the webelement of price and returns it
	 ********************************************************************************/
	public static WebElement price(WebDriver driver) {

		element = driver.findElement(By.id("price"));
		return element;
	}
	
	public static WebElement addToWishList(WebDriver driver)
    {
		element = driver.findElement(By.className("wishList"));
		return element;
    }
	public static WebElement myWishList(WebDriver driver)
    {
		element = driver.findElement(By.id("mywish"));
		return element;
    }
}
