package com.capgemini.pms.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.capgemini.pms.pom.PageObjectModel;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	WebDriver driver;

	@Before
	public void setBrowserEnv() {

		System.setProperty("webdriver.chrome.driver", "D:\\Shiva Godasu\\chromedriver_win32\\chromedriver.exe");
	}

	/*******************************************************************************
	 * -Function name :browser test
	 *  -Return type: Void 
	 *  -Parameters- no 
	 *  -Description: it will open the browser
	 ********************************************************************************/
	@Given("^Open Web browser$")
	public void open_Web_browser() throws Throwable {

		driver = new ChromeDriver();
		driver.manage().window().maximize();

	}

	/*******************************************************************************
	 * -Function name :navigation to product url and enter electronic 
	 * -Return type:Void 
	 * -Parameters- String category 
	 * -Description: It will navigate to product url page and enters electronic into the category field
	 ********************************************************************************/
	@When("^User navigates to product url and  enters category (.+)$")
	public void user_navigates_to_product_url_and_enters_category_electronic(String category) throws Throwable {

		driver.get("http://localhost:4200/list");
		WebElement element = PageObjectModel.category(driver);
		element.sendKeys(category);
		Thread.sleep(3000);
	}

	/*******************************************************************************
	 * -Function name : User clicks on category button -Return type: Void
	 * -Parameters- none -Description: It will click on category button and product
	 * list is displayed
	 ********************************************************************************/
	@When("^User clicks on category product list is displayed$")
	public void user_clicks_on_category_product_list_is_displayed() throws Throwable {

		WebElement element = PageObjectModel.categoryButton(driver);
		element.click();
		Thread.sleep(3000);
	}

	/*******************************************************************************
	 * -Function name : user_selects_low_and_high_from_price_range
	 *  -Return type: Void 
	 *  -Parameters- int low, int high 
	 *  -Description: select the particular range by index
	 ********************************************************************************/
	@When("^User selects low (\\d+) and high (\\d+) from price range$")
	public void user_selects_low_and_high_from_price_range(int low, int high) throws Throwable {

		WebElement element = PageObjectModel.low(driver);
		Select dropdown = new Select(element);
		dropdown.selectByIndex(low);

		Thread.sleep(3000);
		
		element = PageObjectModel.high(driver);
		dropdown = new Select(element);
		dropdown.selectByIndex(high);

		Thread.sleep(3000);

	}

	/*******************************************************************************
	 * -Function name : clicks_price
	 *  -Return type: Void 
	 *  -Parameters- no 
	 *  -Description: clicks the price button
	 ********************************************************************************/
	@When("^Clicks price$")
	public void clicks_price() throws Throwable {
		
		WebElement element = PageObjectModel.price(driver);
		element.click();
		Thread.sleep(3000);
		
	}

	@When("^Range list is displayed and user clicks on a product$")
	public void range_list_is_displayed_and_user_clicks_on_a_product() throws Throwable {
		
		Thread.sleep(3000);
		
		WebElement element = PageObjectModel.product(driver);
		element.click();
	}

	@Then("^Product page is displayed$")
	public void product_page_is_displayed() throws Throwable
	{
		Thread.sleep(3000);
		
	}
	@When("^User Nagivates To Url Page$")
	public void user_Nagivates_To_Url_Page() throws Throwable
	{
		driver.get("http://localhost:4200/product"); 
	}

	@Then("^Click on Add to WishList Icon$")
	public void click_on_Add_to_WishList_Icon() throws Throwable 
	{
	    WebElement element =PageObjectModel.addToWishList(driver);
	    element.click();
	}

	@Then("^User Navigates to Main Page$")
	public void user_Navigates_to_Main_Page() throws Throwable 
	{
	   driver.get("http://localhost:4200/list");
	}

	@Then("^User Clicks On myWishList$")
	public void user_Clicks_On_myWishList() throws Throwable
	{
		 WebElement element =PageObjectModel.myWishList(driver);
		 element.click();
	}



}