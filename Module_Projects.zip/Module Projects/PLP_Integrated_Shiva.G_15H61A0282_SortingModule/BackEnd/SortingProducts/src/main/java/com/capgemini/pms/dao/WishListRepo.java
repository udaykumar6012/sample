package com.capgemini.pms.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.pms.model.WishList;

public interface WishListRepo extends JpaRepository<WishList, Integer> {

	List<WishList> findAllByUserId(int userId);
}
