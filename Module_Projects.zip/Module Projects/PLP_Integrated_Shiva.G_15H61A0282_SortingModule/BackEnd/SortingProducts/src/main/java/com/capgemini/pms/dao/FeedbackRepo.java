package com.capgemini.pms.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.pms.model.FeedbackProduct;

public interface FeedbackRepo extends JpaRepository<FeedbackProduct, Integer> {
	
	
	List<FeedbackProduct> findAllByProductId(int productId);

}
