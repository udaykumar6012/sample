package com.capgemini.pms.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.pms.model.FeedbackProduct;
import com.capgemini.pms.model.MyCart;
import com.capgemini.pms.model.ProductMaster;
import com.capgemini.pms.model.WishList;

@Repository
public class SortingProductsDaoImpl implements SortingProductsDao {

	@Autowired
	SortingProductsRepo repo;

	@Autowired
	FeedbackRepo frepo;

	@Autowired
	WishListRepo wrepo;

	@Autowired
	CartRepo crepo;

	/*************************************************************************
	 * Method name : getProductListByRange 
	 * parameter   : double low,double high,String type 
	 * Return Type : List<ProductMaster> 
	 * Author	   : 15H61A0282 
	 * Description : returns the List of Products within the Range
	 *************************************************************************/
	@Override
	public List<ProductMaster> getProductListByRange(double low, double high, String type) {

		List<ProductMaster> pList = repo.findAll();
		List<ProductMaster> rangeList = new ArrayList<ProductMaster>();

		if (low > high) {
			double temp;
			temp = low;
			low = high;
			high = temp;
		}

		if (!type.equalsIgnoreCase("All")) {
			for (ProductMaster productMaster : pList) {
				if (productMaster.getProductType().equalsIgnoreCase(type)) {
					if (high != 50001) {
						if (productMaster.getProductPrice() >= low && productMaster.getProductPrice() <= high) {

							rangeList.add(productMaster);

						}
					} else {
						if (productMaster.getProductPrice() >= low) {

							rangeList.add(productMaster);

						}
					}
				}
			}
		} else {
			for (ProductMaster productMaster : pList) {
				if (high != 50001) {
					if (productMaster.getProductPrice() >= low && productMaster.getProductPrice() <= high) {

						rangeList.add(productMaster);

					}
				} else {
					if (productMaster.getProductPrice() >= low) {

						rangeList.add(productMaster);

					}
				}

			}
		}

		return rangeList;

	}

	/*************************************************************************
	 * Method name : getAllProductsList parameter : no parameters Return Type :
	 * List<ProductMaster> Author : 15H61A0282 Description : returns all the
	 * products
	 *************************************************************************/
	@Override
	public List<ProductMaster> getAllProductsList() {

		return repo.findAll();
	}

	/*************************************************************************
	 * Method name : getProducts parameter : String type Return Type :
	 * List<ProductMaster> Author : 15H61A0285, 15H61A1249 Description : returns the
	 * products based on type
	 *************************************************************************/
	@Override
	public List<ProductMaster> getProducts(String type) {

		return repo.findAllByProductType(type);
	}

	/*************************************************************************
	 * Method name : getProductById parameter : @PathVariable int productId Return
	 * Type : ProductMaster Author : 15H61A0285, 15H61A1249 Description : returns
	 * the product based on id
	 *************************************************************************/
	@Override
	public ProductMaster getProductById(int productId) {

		ProductMaster master = repo.findById(productId).orElse(null);

		return master;
	}

	/*************************************************************************
	 * Method name : getFeedbackById parameter : @PathVariable int productId Return
	 * Type : List<FeedbackProduct> Author : 15H61A0285, 15H61A1249,15H61A0282
	 * Description : returns the FeedbackLIst based on id
	 *************************************************************************/
	@Override
	public List<FeedbackProduct> getFeedbackById(int productId) {

		return frepo.findAllByProductId(productId);
	}

	@Override
	public int addtoWishList(int userId, int productId) {

		WishList list = new WishList();
		list.setWishListId((int) (Math.random() * 1000));
		list.setUserId(userId);
		list.setProductId(productId);
		wrepo.save(list);
		return productId;
	}

	@Override
	public List<ProductMaster> getWishList(int userId) {

		int temp;
		List<ProductMaster> pList = new ArrayList<ProductMaster>();
		List<WishList> list = wrepo.findAllByUserId(userId);

		for (WishList wishList : list) {

			temp = wishList.getProductId();

			pList.add(repo.findById(temp).orElse(null));

		}

		return pList;
	}

	@Override
	public int addtoCart(int userId, int productId) {

		MyCart cart = new MyCart();
		cart.setCartId((int) (Math.random() * 1000));
		cart.setUserId(userId);
		cart.setProductId(productId);
		crepo.save(cart);

		return productId;
	}
}
