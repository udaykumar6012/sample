package com.capgemini.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.pms.dao.SortingProductsDao;
import com.capgemini.pms.model.FeedbackProduct;
import com.capgemini.pms.model.ProductMaster;

@Service
public class SortingProductsServiceImpl implements SortingProductsService {

	@Autowired
	SortingProductsDao dao;
	

	/*************************************************************************
	* Method name : getProductListByRange
	* parameter   : double low,double high,String type
	* Return Type : List<ProductMaster>
	* Author      : 15H61A0282 
	* Description : returns the List of Products within the Range
	*************************************************************************/
	@Override
	public List<ProductMaster> getAllProductsList() {
		
		return dao.getAllProductsList();
	}

	/*************************************************************************
	* Method name : getAllProductsList
	* parameter	  : no parameters
	* Return Type : List<ProductMaster> 
	* Author	  : 15H61A0282 
	* Description : returns all the products
	*************************************************************************/
	@Override
	public List<ProductMaster> getProductListByRange(double low,double high,String type) {
		
		return dao.getProductListByRange(low, high,type);
	}

	/*************************************************************************
	* Method name : getProducts
	* parameter	  : String type
	* Return Type : List<ProductMaster> 
	* Author	  : 15H61A0285, 15H61A1249
	* Description : returns the products based on type
	*************************************************************************/
	@Override
	public List<ProductMaster> getProducts(String type) {
	
		return dao.getProducts(type);
	}

	/*************************************************************************
	* Method name : getProductById
	* parameter	  : @PathVariable int productId
	* Return Type : ProductMaster 
	* Author	  : 15H61A0285, 15H61A1249
	* Description : returns the product based on id
	*************************************************************************/
	@Override
	public ProductMaster getProductById(int productId) {
	
		return dao.getProductById(productId);
	}

	 /*************************************************************************
	* Method name : getFeedbackById
	* parameter	  : @PathVariable int productId
	* Return Type : List<FeedbackProduct>
	* Author	  : 15H61A0285, 15H61A1249,15H61A0282
	* Description : returns the FeedbackLIst based on id
	*************************************************************************/
	@Override
	public List<FeedbackProduct> getFeedbackById(int productId) {
		
		return dao.getFeedbackById(productId);
	}

	@Override
	public int addtoWishList(int userId,int productId) {
		
		return dao.addtoWishList(userId,productId);
		
	}

	@Override
	public List<ProductMaster> getWishList(int userId) {
		
		return dao.getWishList(userId);
	}

	@Override
	public int addtoCart(int userId, int productId) {
		
		return dao.addtoCart(userId, productId);
	}

}
