package com.capgemini.pms.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import org.springframework.stereotype.Component;

@Component
@Entity
public class FeedbackProduct {
	
	
	
	@Id
	private int productId;
	private int userId;
	private double rating;
	private String feedback;
	@ManyToMany(mappedBy ="feedback")
	 	private Set<ProductMaster> product=new HashSet<>();
	

	

	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public Set<ProductMaster> getProduct() {
		return product;
	}
	public void setProduct(Set<ProductMaster> product) {
		this.product = product;
	}
	
	
}
