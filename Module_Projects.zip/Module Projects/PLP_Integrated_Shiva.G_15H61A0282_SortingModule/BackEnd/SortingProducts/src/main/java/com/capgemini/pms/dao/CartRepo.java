package com.capgemini.pms.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.pms.model.MyCart;
import com.capgemini.pms.model.ProductMaster;

public interface CartRepo extends JpaRepository<MyCart, Integer> {

	List<ProductMaster> findAllByUserId(int userId);
}
