package com.capgemini.pms.service;

import java.util.List;

import com.capgemini.pms.model.FeedbackProduct;
import com.capgemini.pms.model.ProductMaster;

public interface SortingProductsService {

	List<ProductMaster> getAllProductsList();

	List<ProductMaster> getProductListByRange(double low, double high,String type);

	List<ProductMaster> getProducts(String type);

	ProductMaster getProductById(int productId);
	
	List<FeedbackProduct> getFeedbackById(int productId);

	int addtoWishList(int userId, int productid);

	List<ProductMaster> getWishList(int userId);

	int addtoCart(int userId, int productId);

}
