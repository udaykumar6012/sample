package com.capgemini.pms.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.pms.model.ProductMaster;

public interface SortingProductsRepo extends JpaRepository<ProductMaster, Integer> {

	List<ProductMaster> findAllByProductType(String type);

}
