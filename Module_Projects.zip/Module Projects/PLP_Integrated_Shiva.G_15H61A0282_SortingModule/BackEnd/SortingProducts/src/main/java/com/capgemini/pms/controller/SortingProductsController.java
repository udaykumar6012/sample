package com.capgemini.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.pms.model.FeedbackProduct;
import com.capgemini.pms.model.ProductMaster;
import com.capgemini.pms.service.SortingProductsService;

@CrossOrigin("*")
@RestController
public class SortingProductsController {

	@Autowired
	private SortingProductsService service;

	/*************************************************************************
	* Method name : getProductListByRange
	* parameter   : double low,double high,String type
	* Return Type : List<ProductMaster>
	* Author      : 15H61A0282 
	* Description : returns the List of Products within the Range
	*************************************************************************/
	@GetMapping(path = "/get/{low}/{high}/{type}", produces = "application/json")
	public List<ProductMaster> getProductListByRange(@PathVariable double low, @PathVariable double high,@PathVariable String type) {

		return service.getProductListByRange(low, high, type);
	}

	/*************************************************************************
	* Method name : getAllProductsList
	* parameter	  : no parameters
	* Return Type : List<ProductMaster> 
	* Author	  : 15H61A0282 
	* Description : returns all the products
	*************************************************************************/
	@GetMapping(path = "/getAll", produces = "application/json")
	public List<ProductMaster> getAllProductsList() {
		
		return service.getAllProductsList();
	}
	
	/*************************************************************************
	* Method name : getProducts
	* parameter	  : String type
	* Return Type : List<ProductMaster> 
	* Author	  : 15H61A0285, 15H61A1249
	* Description : returns the products based on type
	*************************************************************************/
	@GetMapping(path = "/products/{type}", produces = "application/json")
	  public List<ProductMaster> getProducts(@PathVariable String type)
	  { 
		  return service.getProducts(type);
    }
	 
	/*************************************************************************
	* Method name : getProductById
	* parameter	  : @PathVariable int productId
	* Return Type : ProductMaster 
	* Author	  : 15H61A0285, 15H61A1249
	* Description : returns the product based on id
	*************************************************************************/
	 @GetMapping(path = "/ProductById/{productId}", produces = "application/json")
	  public ProductMaster getProductById(@PathVariable int productId)
	  { 
	
		  return service.getProductById(productId);
	  }
	 
	 /*************************************************************************
		* Method name : getFeedbackById
		* parameter	  : @PathVariable int productId
		* Return Type : List<FeedbackProduct>
		* Author	  : 15H61A0285, 15H61A1249,15H61A0282
		* Description : returns the FeedbackLIst based on id
		*************************************************************************/
	 @GetMapping(path = "/FeedbackById/{productId}", produces = "application/json")
	  public List<FeedbackProduct> getFeedbackById(@PathVariable int productId)
	  { 
	
		  return service.getFeedbackById(productId);
	  } 

	 @PostMapping(path="/addtoWishList/{userId}",consumes="application/json")
	 public int addtoWishList(@PathVariable int userId,@RequestBody int productId) {
		 
		return service.addtoWishList(userId, productId);
		 
	 }
	 
	 @GetMapping(path = "/getWishList/{userId}", produces = "application/json")
	  public List<ProductMaster> getWishList(@PathVariable int userId)
	  { 
	
		  return service.getWishList(userId);
	  } 
	 
	 @PostMapping(path="/addtoCart/{userId}",consumes="application/json")
	 public int addtoCart(@PathVariable int userId,@RequestBody int productId) {
		 return service.addtoCart(userId, productId);
	 }
}
