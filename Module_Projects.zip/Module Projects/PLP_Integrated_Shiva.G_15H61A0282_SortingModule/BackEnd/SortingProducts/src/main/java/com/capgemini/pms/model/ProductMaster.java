package com.capgemini.pms.model;

import java.sql.Blob;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import org.springframework.stereotype.Component;

@Component
@Entity
public class ProductMaster {
	
	@Id
	private int productId;
	private String productName;
	private String productType;
	private double productPrice;
	private String productDesc;
	private Blob productImg;
	private double productAvgRating;
	
	@ManyToMany(cascade = CascadeType.ALL)
 	private Set<FeedbackProduct> feedback=new HashSet<>();

	public Set<FeedbackProduct> getFeedback() {
		return feedback;
	}

	public void setFeedback(Set<FeedbackProduct> feedback) {
		this.feedback = feedback;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public Blob getProductImg() {
		return productImg;
	}

	public void setProductImg(Blob productImg) {
		this.productImg = productImg;
	}

	public double getProductAvgRating() {
		return productAvgRating;
	}

	public void setProductAvgRating(double productAvgRating) {
		this.productAvgRating = productAvgRating;
	}

}
