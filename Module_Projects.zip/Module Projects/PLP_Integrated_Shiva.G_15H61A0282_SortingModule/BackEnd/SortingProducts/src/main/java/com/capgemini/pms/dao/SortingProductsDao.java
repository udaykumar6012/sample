package com.capgemini.pms.dao;

import java.util.List;

import com.capgemini.pms.model.FeedbackProduct;
import com.capgemini.pms.model.ProductMaster;

public interface SortingProductsDao {
	List<ProductMaster> getProductListByRange(double low, double high, String type);

	List<ProductMaster> getAllProductsList();

	ProductMaster getProductById(int productId);

	List<ProductMaster> getProducts(String type);

	List<FeedbackProduct> getFeedbackById(int productId);

	int addtoWishList(int userId, int productId);

	List<ProductMaster> getWishList(int userId);

	int addtoCart(int userId, int productId);
}
