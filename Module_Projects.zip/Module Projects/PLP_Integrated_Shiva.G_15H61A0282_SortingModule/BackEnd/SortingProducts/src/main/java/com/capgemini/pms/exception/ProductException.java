package com.capgemini.pms.exception;

public class ProductException  extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProductException() {
		super("No Products Available");
	}
}
