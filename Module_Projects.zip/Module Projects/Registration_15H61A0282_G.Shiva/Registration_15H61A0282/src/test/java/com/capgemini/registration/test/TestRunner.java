package com.capgemini.registration.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resources/Features", glue = "com.capgemini.registration.stepdefinition",  plugin = { "html:target/cucumber_html_report"})
public class TestRunner {

}
