package com.capgemini.registration.stepdefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.capgemini.registration.pageobjectmodel.Registration;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {

	private WebDriver driver;

	

	/*******************************************************************************
	 -Method name : open_browser()
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- none
	 -Description: Setting the Driver
	 ********************************************************************************/
	@Given("^Open browser$")
	public void open_browser() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Shiva Godasu\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	
	/*******************************************************************************
	 -Function name : user_navigate_to_url()
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- none
	 -Description: Open the Registration Form
	 ********************************************************************************/
	@When("^user navigate to  url$")
	public void user_navigate_to_url() throws Throwable {
		driver.get("D:\\Shiva Godasu\\BDD\\Registration_15H61A0282\\src\\test\\resources\\HTML\\RegistrationForm.html");

	}

	/*******************************************************************************
	 -Function name : check_title()
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- String title
	 -Description: Gets Title web element and verifies title
	 ********************************************************************************/
	@Then("^Check title (.+)$")
	public void check_title(String title) throws Throwable {
		driver.getTitle().equalsIgnoreCase(title);
	}

	/*******************************************************************************
	 -Function name : enter_user_id_Shiva
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- String name
	 -Description: Gets Name web Element and  set the value of name
	 ********************************************************************************/
	
	@Then("^enter user id (.+)$")
	public void enter_user_id_Shiva(String userId) throws Throwable {
		WebElement id = Registration.id(driver);
		id.sendKeys(userId);
	}

	/*******************************************************************************
	 -Function name : enter_password_Shiva
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- String name
	 -Description: Gets password web Element and  set the value of password
	 ********************************************************************************/
	@Then("^enter password (.+)$")
	public void enter_password_Shiva(String password) throws Throwable {
		WebElement pswd = Registration.password(driver);
		pswd.sendKeys(password);
	}

	/*******************************************************************************
	 -Function name : enter_username_shiva_godasu
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- String name
	 -Author - 15H61A0282
	 -Description: Gets Name web Element and  set the value of name
	 ********************************************************************************/
	
	@Then("^Enter username (.+)$")
	public void enter_username_shiva_godasu(String name) throws Throwable {
		WebElement element = Registration.name(driver);
		element.sendKeys(name);
	}

	/*******************************************************************************
	 -Function name : address_Hyderabad
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- String address
	 -Description: Gets Address web Element and  set the value of address
	 ********************************************************************************/
	@Then("^enter address (.+)$")
	public void enter_address_hyderabad(String address) throws Throwable {
		WebElement element = Registration.address(driver);
		element.sendKeys(address);
	}

	/*******************************************************************************
	 -Function name : select_the_country_from_dropdown_list_India
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- String country
	 -Description: Gets Country web Element and  set the value of country
	 ********************************************************************************/
	@Then("^select the country from dropdown list (.+)$")
	public void select_the_country_from_dropdown_list_India(String country) throws Throwable {
		WebElement element = Registration.country(driver);
		Select dropdown = new Select(element);
		dropdown.selectByVisibleText(country);
	}
	/*******************************************************************************
	 -Function name : enter_ZIP_Code
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- String zipCode
	 -Description: Gets ZIP Code web Element and  set the value of Zip Code
	 ********************************************************************************/
	@Then("^enter zip code(.+)$")
	public void enter_zip_code(String zip) throws Throwable {
		WebElement element = Registration.zipCode(driver);
		element.sendKeys(zip);
	}

	/*******************************************************************************
	 -Function name : email_shiva_gmail_com
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- String email
	 -Description: Gets Email web Element and  set the value of Email
	 ********************************************************************************/
	@Then("^enter email (.+)$")
	public void enter_email_shiva_gmail_com(String email) throws Throwable {
		WebElement element = Registration.email(driver);
		element.sendKeys(email);
	}/*******************************************************************************
	 -Function name :select_radio_button_for_gender_Male
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- String gender
	 -Description: Gets Gender web Element and  set the value of Gender
	 ********************************************************************************/

	@Then("^select radio button for  gender (.+)$")
	public void select_radio_button_for_gender_Male(String gender) throws Throwable {
		WebElement element = Registration.gender(driver, gender);
		element.click();
	}

	/*******************************************************************************
	 -Function name :select_the_checkbox_for_language_English
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- String language
	 -Description: Gets language web Element and  set the value of Language
	 ********************************************************************************/
	@Then("^select the  checkbox for language (.+)$")
	public void select_the_checkbox_for_language_English(String language) throws Throwable {
		WebElement element = Registration.language(driver, language);
		element.click();
	}

	/*******************************************************************************
	 -Function name :enter_about_details_Anurag_Group
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- String language
	 -Description: Gets about web Element and  set the value of about
	 ********************************************************************************/
	@Then("^enter about details (.+)$")
	public void enter_about_details_Anurag_Group(String about) throws Throwable {
		WebElement element = Registration.about(driver);
		element.sendKeys(about);

	}
	/*******************************************************************************
	 -Function name :submitted_Successfully()
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- No
	 -Description: Gets Submit web Element and Click on the button 
	 ********************************************************************************/
	@Then("^Submitted Successfully$")
	public void submitted_Successfully() throws Throwable {
		WebElement element = Registration.submit(driver);
		//element.click();
		
	}
	/*******************************************************************************
	 -Function name :close_the_browser()
	 -Author name: 15H61A0282
	 -Return type: Void
	 -Parameters- No
	 -Description: Closes the browser
	 ********************************************************************************/
	@Then("^close the browser$")
	public void close_the_browser() throws Throwable {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//driver.quit();
	}


}
