package com.capgemini.registration.pageobjectmodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Registration {

	public static WebElement element = null;

	/*******************************************************************************
	 -Function name : name
	 -Author name: 15H61A0282
	 -Return type: WebDriver
	 -Parameters- WebDriver driver
	 -Description: Gets Submit web Element of username
	 ********************************************************************************/
	public static WebElement name(WebDriver driver) {

		element = driver.findElement(By.id("usrname"));
		return element;
	}
	
	/*******************************************************************************
	 -Function name : adress
	 -Author name: 15H61A0282
	 -Return type: WebDriver
	 -Parameters- WebDriver driver
	 -Description: Gets Submit web Element of address
	 ********************************************************************************/

	public static WebElement address(WebDriver driver) {

		element = driver.findElement(By.id("addr"));
		return element;
	}
	/*******************************************************************************
	 -Function name : country
	 -Author name: 15H61A0282
	 -Return type: WebDriver
	 -Parameters- WebDriver driver
	 -Description: Gets Submit web Element of country
	 ********************************************************************************/
	public static WebElement country(WebDriver driver) {

		element = driver.findElement(By.name("country"));
		return element;
	}
	/*******************************************************************************
	 -Function name : zipCode
	 -Author name: 15H61A0282
	 -Return type: WebDriver
	 -Parameters- WebDriver driver
	 -Description: Gets Submit web Element of zipcode
	 ********************************************************************************/
	public static WebElement zipCode(WebDriver driver) {

		element = driver.findElement(By.name("zip"));
		return element;
	}
	/*******************************************************************************
	 -Function name : email
	 -Author name: 15H61A0282
	 -Return type: WebDriver
	 -Parameters- WebDriver driver
	 -Description: Gets Submit web Element of email
	 ********************************************************************************/
	public static WebElement email(WebDriver driver) {

		element = driver.findElement(By.name("email"));
		return element;
	}
	/*******************************************************************************
	 -Function name : gender
	 -Author name: 15H61A0282
	 -Return type: WebDriver
	 -Parameters- WebDriver driver , String gender
	 -Description: Gets Submit web Element of gender
	 ********************************************************************************/
	public static WebElement gender(WebDriver driver, String gender) {

		element = driver.findElement(By.name("sex"));
		return element;
	}

	/*******************************************************************************
	 -Function name : language
	 -Author name: 15H61A0282
	 -Return type: WebDriver
	 -Parameters- WebDriver driver,String language
	 -Description: Gets Submit web Element of language
	 ********************************************************************************/
	public static WebElement language(WebDriver driver, String language) {

		element = driver.findElement(By.name(language));
		return element;
	}
	/*******************************************************************************
	 -Function name : submit
	 -Author name: 15H61A0282
	 -Return type: WebDriver
	 -Parameters- WebDriver driver
	 -Description: Gets Submit web Element of submit
	 ********************************************************************************/
	public static WebElement submit(WebDriver driver) {

		element = driver.findElement(By.name("submit"));
		return element;
	}
	/*******************************************************************************
	 -Function name : id
	 -Author name: 15H61A0282
	 -Return type: WebDriver
	 -Parameters- WebDriver driver
	 -Description: Gets Submit web Element of user id
	 ********************************************************************************/
	public static WebElement id(WebDriver driver) {
		element = driver.findElement(By.id("usrID"));
		return element;
	}
	/*******************************************************************************
	 -Function name : password
	 -Author name: 15H61A0282
	 -Return type: WebDriver
	 -Parameters- WebDriver driver
	 -Description: Gets Submit web Element of pswd
	 ********************************************************************************/
	public static WebElement password(WebDriver driver) {
		element = driver.findElement(By.id("pwd"));
		return element;
	}
	/*******************************************************************************
	 -Function name : about
	 -Author name: 15H61A0282
	 -Return type: WebDriver
	 -Parameters- WebDriver driver
	 -Description: Gets Submit web Element of about
	 ********************************************************************************/
	public static WebElement about(WebDriver driver) {
		element = driver.findElement(By.id("desc"));
		return element;
	}

}
