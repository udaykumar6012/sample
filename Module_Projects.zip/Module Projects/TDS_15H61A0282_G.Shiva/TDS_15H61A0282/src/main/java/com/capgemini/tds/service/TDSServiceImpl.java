package com.capgemini.tds.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.tds.dao.TDSDao;
import com.capgemini.tds.model.TdsMaster;

@Service
public class TDSServiceImpl implements TDSService {

	@Autowired
	TDSDao dao;

	@Override
	public List<TdsMaster> displayAll() {

		return dao.displayAll();
	}

	@Override
	public TdsMaster getTds(int id) {

		return dao.getTds(id);
	}

}
