package com.capgemini.tds.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
@Entity
public class TdsMaster {

	@Id
	private int id;
	private String deductorName;
	private String deductorPan;
	private double tdsDeposited;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDeductorName() {
		return deductorName;
	}

	public void setDeductorName(String deductorName) {
		this.deductorName = deductorName;
	}

	public String getDeductorPan() {
		return deductorPan;
	}

	public void setDeductorPan(String deductorPan) {
		this.deductorPan = deductorPan;
	}

	public double getTdsDeposited() {
		return tdsDeposited;
	}

	public void setTdsDeposited(double tdsDeposited) {
		this.tdsDeposited = tdsDeposited;
	}

	@Override
	public String toString() {
		return "TdsMaster [id=" + id + ", deductorName=" + deductorName + ", deductorPlan=" + deductorPan
				+ ", tdsDeposited=" + tdsDeposited + "]";
	}

}
