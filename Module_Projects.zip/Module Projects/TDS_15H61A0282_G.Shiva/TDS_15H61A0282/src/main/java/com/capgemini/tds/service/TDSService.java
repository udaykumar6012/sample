package com.capgemini.tds.service;

import java.util.List;

import com.capgemini.tds.model.TdsMaster;



public interface TDSService {

	public List<TdsMaster> displayAll();

	public TdsMaster getTds(int id);
	
}
