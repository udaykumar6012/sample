package com.capgemini.tds.dao;

import java.util.List;

import com.capgemini.tds.model.TdsMaster;

public interface TDSDao {

	public List<TdsMaster> displayAll();

	public TdsMaster getTds(int id);
}
