package com.capgemini.tds.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.exception.TDSException;
import com.capgemini.tds.model.TdsMaster;
import com.capgemini.tds.service.TDSService;

@RestController
public class TDSController {

	@Autowired
	TDSService service;

	/*
	 * Method Name : getAll
	 * Return type : List<TdsMaster>
	 * Description : It gives complete TDSLIST 
	 * 
	 */

	@RequestMapping(path = "/tds", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<TdsMaster> getAll() {

		List<TdsMaster> tdsList = service.displayAll();

		return tdsList;
	}
	/*
	 * Method Name : getTds
	 * Arguments   : id (int type)
	 * Return type : TdsMaster
	 * Description : It finds gives single result by taking id
	 * 
	 */

	@GetMapping(path = "/tds/{id}", produces = "application/json")
	public TdsMaster getTds(@PathVariable int id) {

		TdsMaster tds = service.getTds(id);
		if (tds == null) {

			TDSException exp = new TDSException();

			throw exp;
		}

		return tds;

	}

}
