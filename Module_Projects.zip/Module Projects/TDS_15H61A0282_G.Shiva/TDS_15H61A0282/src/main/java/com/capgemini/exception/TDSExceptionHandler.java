package com.capgemini.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class TDSExceptionHandler {
	@ExceptionHandler
	public ResponseEntity<ErrorResponse> handleError(TDSException exception, WebRequest req) {
		ErrorResponse eResponse = new ErrorResponse(new Date(24, 04, 2019), "ID NOT FOUND", req.getDescription(false));
		return new ResponseEntity<ErrorResponse>(eResponse, HttpStatus.NOT_FOUND);

	}

}
