package com.capgemini.exception;

public class TDSException  extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
