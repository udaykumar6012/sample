package com.capgemini.tds.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.tds.model.TdsMaster;

public interface TDSRepo extends JpaRepository<TdsMaster,Integer> {

}
