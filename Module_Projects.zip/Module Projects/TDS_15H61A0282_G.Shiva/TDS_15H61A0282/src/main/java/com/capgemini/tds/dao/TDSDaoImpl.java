package com.capgemini.tds.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.tds.model.TdsMaster;

@Repository
public class TDSDaoImpl implements TDSDao {

	@Autowired
	TDSRepo repo;
	
	@Override
	public List<TdsMaster> displayAll() {

		return repo.findAll();
	}

	@Override
	public TdsMaster getTds(int id) {
		
		return repo.findById(id).orElse(null);
	}

}
