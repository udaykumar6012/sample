package com.capgemini.BankingSystem.Dao;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.capgemin.BankingSystem.Bean.Transactions;
import com.capgemini.BankingSystem.Utility.BankingRepository;

public class BankinSystemDao implements IBankingSystemDao {
	
	BankingRepository br=new BankingRepository();
	Map<Integer, Transactions> transactionsMap = new LinkedHashMap<Integer, Transactions>();
	public BankinSystemDao() {
		transactionsMap.putAll(br.getTransList());
	}
	
	
	int id=0;
	
	@Override
	public Map<Integer, Transactions> getAllTransactions() {
		return transactionsMap;
	}

	@Override
	public boolean addTransaction(Transactions tran,int transactId) {
		Transactions status = transactionsMap.put(transactId, tran);
		
	       if(status==null)
	    	   return true;
	       else
	    	   return false;
	}
	

}
