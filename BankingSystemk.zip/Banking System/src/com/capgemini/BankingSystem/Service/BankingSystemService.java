package com.capgemini.BankingSystem.Service;

import java.util.ArrayList;
import java.util.Collection;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemin.BankingSystem.Bean.Transactions;
import com.capgemini.BankingSystem.Dao.BankinSystemDao;
import com.capgemini.BankingSystem.Dao.IBankingSystemDao;
import com.capgemini.BankingSystem.Exception.BankingException;

public class BankingSystemService implements IBankingService {

	int transactId = 0;double accountNo;
	IBankingSystemDao dao = new BankinSystemDao();
	Transactions transactions = new Transactions();
	static private double balance=2000;
	

	@Override
	public int addTransact(Transactions tran) {
		transactId = (int) (Math.random() *1000);
		tran.setTranscationId(transactId);
		boolean status = dao.addTransaction(tran,transactId);
		if (status)
			return transactId;
		
		return 0;
		
	}

	@Override
	public List<Transactions> printAllTransactions() {
		List<Transactions> transactList=new ArrayList<>();
		Collection<Transactions> collection=dao.getAllTransactions().values();
		transactList.addAll(collection);
		
		return transactList;
	}

	@Override
	public boolean narration(String string, double amount) {
		
		switch(string)
		{
		case "debit": balance -=amount;break;
		case "credit": balance+=amount; break;
		case "transfer": balance-=amount; break;
		}
	  	return true;
		
	}
	
	@Override
	public boolean isPhonevalid(String phone) throws BankingException {
		Pattern nameptn = Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher match = nameptn.matcher(phone);
		if (match.matches()) {
			return true;
		}
		else
		return false;
	}

	@Override
	public boolean isNamevalid(String name) throws BankingException {
		Pattern nameptn = Pattern.compile("^[A-Z]{1}[a-z]{4,}$");
		Matcher match = nameptn.matcher(name);
		if (match.matches()) {
			return true;
		}
		else
		return false;
	}
	@Override
	public boolean isAadhaarvalid(String name) throws BankingException {
		Pattern nameptn = Pattern.compile("^[0-9 ]{12}$");
		Matcher match = nameptn.matcher(name);
		if (match.matches()) {
			return true;
		}
		else
		return false;
	}

	public int accountNo() {
		accountNo = (Math.random() *10000000);
		return (int) accountNo;
	}

	@Override
	public double balance() {
		return balance;
	}

}
