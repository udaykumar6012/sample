package com.capgemin.BankingSystem.Bean;

public class Transactions {
	private double amount;
	private double balance;
	private String date;
	private String narration;
	private int transcationId;
	public Transactions() {
		super();
	}
	public Transactions(int transcationId,double amount,double balance , String date,String narration) {
		super();
		this.amount = amount;
		this.date = date;
		this.balance= balance;
		this.narration = narration;
		this.transcationId = transcationId;
	}
	
	
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public double getamount() {
		return amount;
	}
	public void setamount(double amount) {
		this.amount = amount;
	}
	
	public int getTranscationId() {
		return transcationId;
	}
	public void setTranscationId(int transcationId) {
		this.transcationId = transcationId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getNarration() {
		return narration;
	}
	public void setNarration(String narration) {
		this.narration = narration;
	}
	@Override
	public String toString() {
		return date+"\t\t"+ transcationId+ "\t\t" +balance+"\t           "+ amount +"\t\t" +narration;
	}
	
	
	
	
	
}
