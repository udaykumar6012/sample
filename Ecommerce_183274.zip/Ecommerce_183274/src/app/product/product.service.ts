import { Injectable } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';
import { Iproducts } from './product.interface';

@Injectable({
  providedIn: 'root'
})
/***
 * Author :Challa Saranya
 * Created on : 13-07-2019
 * purpose: This class is used for accessing 
 * the data from the json file
 *
 */
export class ProductService {
  products:Iproducts[];

  constructor(private http:HttpClient) {
  
   }
  getProducts():Observable<Iproducts[]>{
    return this.http.get<Iproducts[]>("./assets/db.json");
  }
  
}
