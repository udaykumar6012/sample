import { Component, OnInit } from '@angular/core';
import { Iproducts } from './product.interface';
import { ProductService } from './product.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-productsearch',
  templateUrl: './productsearch.component.html',
  styleUrls: ['./productsearch.component.css']
})
export class ProductsearchComponent implements OnInit {
  products:Iproducts[];
  searchTerm:any;
  searchTerm1:any;


  constructor(private productservice:ProductService,private router:Router) { }

  ngOnInit() {
    this.productservice.getProducts().subscribe((data)=>this.products=data)
    console.log(this.products)
  }
  /***
 * Author :Challa Saranya
 * Created on : 13-07-2019
 * purpose: This method is used to
 *search the paticular product from the list
 *
 */
  onSearch(){
    this.searchTerm1=this.searchTerm;
  }

}
