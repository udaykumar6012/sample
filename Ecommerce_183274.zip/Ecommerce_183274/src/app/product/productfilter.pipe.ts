import { Pipe, PipeTransform } from '@angular/core';
import { Iproducts } from './product.interface';

@Pipe({
  name: 'productfilter'
})
/***
 * Author :Challa Saranya
 * Created on : 13-07-2019
 * purpose: This is a pipe class to filter the search
 * data
 *
 */

export class ProductfilterPipe implements PipeTransform {

  transform(products:Iproducts[],searchTerm:any): any {
    if(!products||!searchTerm){
      return products;
    }
    return products.filter(e=>e.name.toLowerCase().startsWith(searchTerm.toLowerCase()));

  }

}
