/* **
 * Author :Challa Saranya
 * Created on : 13-07-2019
 * purpose: This is an interface
 * to get the details
 *
 */
 

export interface Iproducts{
    id:string,
    name:string,
    price:number,
    category:string

}