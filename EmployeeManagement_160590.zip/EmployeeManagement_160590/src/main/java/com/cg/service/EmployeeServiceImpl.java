package com.cg.service;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Employee;
import com.cg.dao.IEmployeeRepo;
import com.cg.exception.EmployeeException;
import com.cg.exception.ExceptionMessage;

@Service
public class EmployeeServiceImpl implements IEmployeeService{
	
	@Autowired
	private IEmployeeRepo repo;

	@Override
	public List<Employee> createEmployee(Employee employee)   {
		repo.save(employee);
		return  repo.findAll();
	}

	@Override
	public List<Employee> getAllEmployee() {
		return  repo.findAll();
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		Optional<Employee> employees = repo.findById(employee.getEmp_Id());
		Employee e=employees.get();
		e.setName(employee.getName());
		e.setDesignation(employee.getDesignation());
		e.setDept_Name(employee.getDept_Name());
		e.setSalary(employee.getSalary());
		repo.save(e);
		return e;
	}

	@Override
	public void delEmployee(Integer Emp_Id) throws EmployeeException {

		 Optional<Employee> employee = repo.findById(Emp_Id);
			if(employee.isPresent())
	        {
				repo.deleteById(Emp_Id);

	        } else {
	            throw new EmployeeException(ExceptionMessage.MESSAGE2);
	        }
		
	}

	@Override
	public Employee getEmployeeById(Integer Emp_Id) {
		return repo.findById(Emp_Id).get();
	}

	@Override
	public List<Employee> getEmployeeByDept_Name(String Dept_Name) {
		List<Employee> list=repo.findAll();
		List<Employee> list1=new ArrayList<>();
		for(Employee e:list) {
			if(e.getDept_Name().equals(Dept_Name)) {
				list1.add(e);	
			}
		}
		return list1;
	}

	
}
