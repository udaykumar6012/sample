package com.cg.service;

import java.util.List;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;

public interface IEmployeeService {
	
	List<Employee> createEmployee(Employee employee);

	List<Employee> getAllEmployee();

	Employee updateEmployee(Employee employee);

	void delEmployee(Integer Emp_Id) throws EmployeeException;

	Employee getEmployeeById(Integer Emp_Id);

	List<Employee> getEmployeeByDept_Name(String Dept_Name);

}
