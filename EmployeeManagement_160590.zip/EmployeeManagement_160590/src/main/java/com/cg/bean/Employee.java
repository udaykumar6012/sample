package com.cg.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Employee implements Serializable {
	
	@Id
	@GeneratedValue
	private Integer Emp_Id;
	
	private String Name;
	private String Designation;
	private String Dept_Name;
	private Integer Salary;
	public Integer getEmp_Id() {
		return Emp_Id;
	}
	public void setEmp_Id(Integer emp_Id) {
		Emp_Id = emp_Id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
	public String getDept_Name() {
		return Dept_Name;
	}
	public void setDept_Name(String dept_Name) {
		Dept_Name = dept_Name;
	}
	public Integer getSalary() {
		return Salary;
	}
	public void setSalary(Integer salary) {
		Salary = salary;
	}
	public Employee() {
		
	}
	@Override
	public String toString() {
		return "Employee [Emp_Id=" + Emp_Id + ", Name=" + Name + ", Designation=" + Designation + ", Dept_Name="
				+ Dept_Name + ", Salary=" + Salary + "]";
	}

}
