package com.cg.exception;

public class EmployeeException extends Exception{
	
	public EmployeeException(String message1) {
		
	}
	public EmployeeException() {
		
	}
}
