package com.cg.exception;

public interface ExceptionMessage {
	String MESSAGE1="due to internal error";
	String MESSAGE2 = "no employee with that id ";

}
