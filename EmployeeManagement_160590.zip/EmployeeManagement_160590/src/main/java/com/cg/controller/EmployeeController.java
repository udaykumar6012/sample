package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;
import com.cg.service.IEmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	private IEmployeeService service;

	@RequestMapping(value = "/createEmployee", method = RequestMethod.POST)
	public List<Employee> createEmployee(@RequestBody Employee employee) {
		return  service.createEmployee(employee);
	}
	@RequestMapping(value = "/getAllEmployee", method = RequestMethod.GET)
	public List<Employee> getAllEmployee() {
		return  service.getAllEmployee();
	}
	
	@RequestMapping(value = "/updateEmployee", method = RequestMethod.PUT)
	public Employee updateEmployee(@RequestBody Employee employee) {
		return  service.updateEmployee(employee);
	}
	
	@RequestMapping(value = "/delEmployee/{pid}", method = RequestMethod.DELETE)
	public String delEmployee(@PathVariable("pid") Integer Emp_Id) throws EmployeeException {
		service.delEmployee(Emp_Id);
		return  Emp_Id+" is deleted";
	}
	@RequestMapping(value = "/getDept_Name/{name1}", method = RequestMethod.GET)
	public List<Employee> getEmployeeByDept_Name(@PathVariable("name1") String n1) {
		return service.getEmployeeByDept_Name(n1);
	}
	@RequestMapping(value = "/getById/{pid}", method = RequestMethod.GET)
	public Employee getProductById(@PathVariable("pid") Integer Emp_Id) {
			return  service.getEmployeeById(Emp_Id);
	}

}
