package testingDemo;

public @interface CucumberOptions {

}
